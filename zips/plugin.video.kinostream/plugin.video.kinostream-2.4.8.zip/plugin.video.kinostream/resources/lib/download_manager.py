# -*- coding: utf-8 -*-
import os
import time
import urllib.request
import urllib.error
import xbmc
import xbmcgui
import xbmcvfs
from .common import get_download_dir, safe_filename, get_setting, notify, log
from . import download_store


class DownloadError(Exception):
    pass


class DownloadManager:
    def __init__(self):
        try:
            self.chunk_size = max(64, int(get_setting('chunk_kb', '256'))) * 1024
        except Exception:
            self.chunk_size = 256 * 1024
        self.overwrite = get_setting('overwrite_existing', 'false').lower() == 'true'

    def choose_target(self, display_name):
        filename = safe_filename(display_name)
        target_dir = get_download_dir()
        return os.path.join(target_dir, filename)

    def probe_existing(self, path):
        return xbmcvfs.exists(path)

    def download(self, item_id, url, display_name):
        target_path = self.choose_target(display_name)
        final_path = target_path
        if self.probe_existing(final_path) and not self.overwrite:
            base, ext = os.path.splitext(final_path)
            stamp = time.strftime('%Y%m%d_%H%M%S')
            final_path = '{}_{}{}'.format(base, stamp, ext)

        progress = xbmcgui.DialogProgress()
        try:
            progress.create('Stahování', display_name, '', '')
        except TypeError:
            progress.create('Stahování', display_name)

        meta = {
            'id': item_id,
            'name': display_name,
            'target_path': final_path,
            'status': 'starting',
            'progress': 0,
            'source_url': url,
        }
        download_store.upsert(item_id, meta)

        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'Kodi-Download-Helper/1.0'})
            response = urllib.request.urlopen(req, timeout=30)
            total_header = response.headers.get('Content-Length') or response.headers.get('content-length')
            total = int(total_header) if total_header and total_header.isdigit() else 0

            meta['status'] = 'downloading'
            download_store.upsert(item_id, meta)

            written = 0
            with open(final_path, 'wb') as out:
                while not xbmc.Monitor().abortRequested():
                    if progress.iscanceled():
                        meta['status'] = 'canceled'
                        meta['progress'] = meta.get('progress', 0)
                        download_store.upsert(item_id, meta)
                        try:
                            out.close()
                        except Exception:
                            pass
                        try:
                            if xbmcvfs.exists(final_path):
                                xbmcvfs.delete(final_path)
                        except Exception:
                            pass
                        notify('Stahování zrušeno: {}'.format(display_name))
                        return None
                    chunk = response.read(self.chunk_size)
                    if not chunk:
                        break
                    out.write(chunk)
                    written += len(chunk)
                    percent = int((written * 100) / total) if total > 0 else 0
                    if total > 0:
                        downloaded_mb = written / (1024.0 * 1024.0)
                        total_mb = total / (1024.0 * 1024.0)
                        line1 = '{} - {} %'.format(display_name, percent)
                        line2 = 'Velikost: {:.0f}/{:.0f} MB'.format(downloaded_mb, total_mb)
                    else:
                        line1 = '{} (bez známé velikosti)'.format(display_name)
                        downloaded_mb = written / (1024.0 * 1024.0)
                        line2 = 'Staženo: {:.0f} MB'.format(downloaded_mb)
                    try:
                        progress.update(percent, line1, line2, 'Storno = zrušit stahování')
                    except TypeError:
                        try:
                            progress.update(percent, line1, line2)
                        except TypeError:
                            progress.update(percent, line1)
                    meta['progress'] = percent
                    meta['downloaded_bytes'] = written
                    meta['total_bytes'] = total
                    download_store.upsert(item_id, meta)

            try:
                if total > 0:
                    done_line_1 = '{} - 100 %'.format(display_name)
                    done_line_2 = 'Velikost: {:.0f}/{:.0f} MB'.format(written / (1024.0 * 1024.0), total / (1024.0 * 1024.0))
                else:
                    done_line_1 = '{} - 100 %'.format(display_name)
                    done_line_2 = 'Dokončeno'
                progress.update(100, done_line_1, done_line_2, '')
            except TypeError:
                try:
                    progress.update(100, done_line_1, done_line_2)
                except TypeError:
                    progress.update(100, display_name)
            xbmc.sleep(500)
            meta['status'] = 'done'
            meta['progress'] = 100
            meta['downloaded_bytes'] = written
            meta['total_bytes'] = total
            download_store.upsert(item_id, meta)
            notify('Staženo: {}'.format(display_name))
            return final_path
        except (urllib.error.URLError, OSError, ValueError) as exc:
            log('Download failed: {}'.format(exc), xbmc.LOGERROR)
            meta['status'] = 'error'
            meta['error'] = str(exc)
            download_store.upsert(item_id, meta)
            raise DownloadError(str(exc))
        finally:
            progress.close()
