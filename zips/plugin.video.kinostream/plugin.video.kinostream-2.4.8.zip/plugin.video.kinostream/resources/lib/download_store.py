# -*- coding: utf-8 -*-
import json
import os
import time
import xbmcvfs
from .common import translate, ensure_dir, ADDON_ID

STORE_PATH = translate('special://profile/addon_data/{}/downloads_state.json'.format(ADDON_ID))


def _read():
    if not xbmcvfs.exists(STORE_PATH):
        return {}
    f = xbmcvfs.File(STORE_PATH)
    try:
        raw = f.read()
    finally:
        f.close()
    if not raw:
        return {}
    try:
        return json.loads(raw)
    except Exception:
        return {}


def _write(data):
    ensure_dir(os.path.dirname(STORE_PATH))
    f = xbmcvfs.File(STORE_PATH, 'w')
    try:
        f.write(json.dumps(data, ensure_ascii=False, indent=2))
    finally:
        f.close()


def list_items():
    data = _read()
    items = list(data.values())
    items.sort(key=lambda x: x.get('updated_at', 0), reverse=True)
    return items


def upsert(item_id, item):
    data = _read()
    item['updated_at'] = int(time.time())
    data[item_id] = item
    _write(data)


def get(item_id):
    return _read().get(item_id)



def remove(item_id):
    data = _read()
    if item_id in data:
        del data[item_id]
        _write(data)


def remove_by_target_path(target_path):
    data = _read()
    changed = False
    for key, value in list(data.items()):
        if (value or {}).get('target_path') == target_path:
            del data[key]
            changed = True
    if changed:
        _write(data)
