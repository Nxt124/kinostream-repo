# -*- coding: utf-8 -*-
import os
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
from .common import HANDLE, build_url, get_download_dir, notify
from . import download_store


def add_main_menu_items():
    li = xbmcgui.ListItem(label='Stažené soubory')
    li.setArt({'icon': 'DefaultFolder.png'})
    xbmcplugin.addDirectoryItem(HANDLE, build_url({'mode': 'downloads'}), li, True)

    li = xbmcgui.ListItem(label='Ukázkové zdroje')
    li.setArt({'icon': 'DefaultVideo.png'})
    xbmcplugin.addDirectoryItem(HANDLE, build_url({'mode': 'sources_demo'}), li, True)

    li = xbmcgui.ListItem(label='Nastavení')
    li.setArt({'icon': 'DefaultAddonProgram.png'})
    xbmcplugin.addDirectoryItem(HANDLE, build_url({'mode': 'settings'}), li, False)

    xbmcplugin.endOfDirectory(HANDLE)


def list_downloaded_files():
    path = get_download_dir()
    dirs, files = xbmcvfs.listdir(path)

    state_by_path = {item.get('target_path'): item for item in download_store.list_items()}

    for name in sorted(files):
        full_path = os.path.join(path, name)
        state = state_by_path.get(full_path)
        label = name
        if state and state.get('status') == 'done':
            label = '{} [Staženo]'.format(name)
        li = xbmcgui.ListItem(label=label)
        li.setPath(full_path)
        li.setProperty('IsPlayable', 'true')
        li.setArt({'icon': 'DefaultVideo.png', 'thumb': 'DefaultVideo.png'})
        li.addContextMenuItems([
            ('Smazat soubor', 'RunPlugin({})'.format(build_url({'mode': 'delete_local', 'path': full_path, 'name': name})))
        ])
        xbmcplugin.addDirectoryItem(
            HANDLE,
            build_url({'mode': 'download_item_action', 'path': full_path, 'name': name}),
            li,
            False
        )

    xbmcplugin.endOfDirectory(HANDLE)


def show_downloaded_item_actions(path, name=''):
    actions = ['Přehrát', 'Smazat', 'Zrušit']
    # Context menu is more compact and works better across PC/TV/Raspberry Kodi setups.
    choice = xbmcgui.Dialog().contextmenu(actions)
    if choice == 0:
        return 'play'
    if choice == 1:
        return 'delete'
    return None


def show_source_actions(source):
    title = source.get('title', 'Zdroj')
    actions = ['Přehrát', 'Stáhnout', 'Zrušit']
    choice = xbmcgui.Dialog().select(title, actions)
    if choice == 0:
        return 'play'
    if choice == 1:
        return 'download'
    return None


def list_demo_sources():
    demo = [
        {
            'id': 'sample1',
            'title': 'Ukázka 1 - vlastní video.mp4',
            'size': '1.4 GB',
            'url': 'https://example.com/video1.mp4'
        },
        {
            'id': 'sample2',
            'title': 'Ukázka 2 - vlastní video.mkv',
            'size': '3.1 GB',
            'url': 'https://example.com/video2.mkv'
        },
    ]

    for src in demo:
        state = download_store.get(src['id'])
        suffix = ''
        if state:
            status = state.get('status')
            if status == 'downloading':
                suffix = ' — {}%'.format(state.get('progress', 0))
            elif status == 'done':
                suffix = ' — Staženo'
            elif status == 'error':
                suffix = ' — Chyba'

        label = '{} [{}]{}'.format(src['title'], src['size'], suffix)
        li = xbmcgui.ListItem(label=label)
        li.setProperty('IsPlayable', 'true')
        encoded = urllib.parse.quote_plus(str(src))
        xbmcplugin.addDirectoryItem(HANDLE, build_url({
            'mode': 'source_action',
            'id': src['id'],
            'title': src['title'],
            'url': src['url'],
        }), li, False)

    xbmcplugin.endOfDirectory(HANDLE)
