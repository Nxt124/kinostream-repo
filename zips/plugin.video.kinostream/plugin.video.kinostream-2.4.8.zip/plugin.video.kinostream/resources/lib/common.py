# -*- coding: utf-8 -*-
import os
import sys
import json
import urllib.parse
import xbmc
import xbmcaddon
import xbmcplugin
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE_URL = sys.argv[0] if len(sys.argv) > 0 else ''


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f'[{ADDON_ID}] {msg}', level)


def build_url(params):
    return BASE_URL + '?' + urllib.parse.urlencode(params)


def notify(message, icon=xbmcgui.NOTIFICATION_INFO, ms=3000):
    xbmcgui.Dialog().notification(ADDON_NAME, message, icon, ms)


def get_setting(key, default=''):
    try:
        return ADDON.getSetting(key)
    except Exception:
        return default


def set_setting(key, value):
    ADDON.setSetting(key, value)


def translate(path):
    return xbmcvfs.translatePath(path)


def ensure_dir(path):
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)
    return path


def get_default_download_dir():
    # Nejpraktičtější bezpečný default uvnitř userdata addonu.
    path = translate('special://profile/addon_data/{}/downloads/'.format(ADDON_ID))
    return ensure_dir(path)


def get_download_dir():
    setting = get_setting('download_path', '')
    if setting:
        return ensure_dir(translate(setting))
    return get_default_download_dir()


def safe_filename(name):
    bad = '<>:"/\\|?*\n\r\t'
    cleaned = ''.join('_' if c in bad else c for c in name).strip().strip('.')
    return cleaned or 'download'


def parse_json_param(value, default=None):
    if not value:
        return default
    try:
        return json.loads(value)
    except Exception:
        return default
