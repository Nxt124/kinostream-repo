# -*- coding: utf-8 -*-
import os
import sys
import urllib.parse
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
from .common import HANDLE, log, notify
from .ui import add_main_menu_items, list_downloaded_files, list_demo_sources, show_source_actions
from .download_manager import DownloadManager, DownloadError


def _params():
    if len(sys.argv) < 3 or not sys.argv[2]:
        return {}
    return dict(urllib.parse.parse_qsl(sys.argv[2].lstrip('?')))


def _play_url(url, title=''):
    li = xbmcgui.ListItem(path=url)
    li.setProperty('IsPlayable', 'true')
    if title:
        li.setLabel(title)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def _play_local(path):
    li = xbmcgui.ListItem(path=path)
    li.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def run():
    p = _params()
    action = p.get('action')

    if not action:
        add_main_menu_items()
        return

    if action == 'downloads':
        list_downloaded_files()
        return

    if action == 'sources_demo':
        list_demo_sources()
        return

    if action == 'settings':
        xbmcaddon.Addon().openSettings()
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    if action == 'play_local':
        _play_local(p['path'])
        return

    if action == 'source_action':
        source = {'id': p.get('id'), 'title': p.get('title'), 'url': p.get('url')}
        picked = show_source_actions(source)
        if picked == 'play':
            _play_url(source['url'], source['title'])
            return
        if picked == 'download':
            mgr = DownloadManager()
            try:
                mgr.download(source['id'], source['url'], source['title'])
            except DownloadError as exc:
                notify('Chyba stahování: {}'.format(exc), xbmcgui.NOTIFICATION_ERROR, 5000)
            xbmc.executebuiltin('Container.Refresh')
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
