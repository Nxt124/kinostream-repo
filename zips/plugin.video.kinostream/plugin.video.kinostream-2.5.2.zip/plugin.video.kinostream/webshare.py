# -*- coding: utf-8 -*-
"""
Webshare.cz API — Kino Stream
Login přesně dle funkčních pluginů yawsp/wsc/kodi-czsk:
  password = SHA1( md5crypt(password, salt) ).hexdigest()
  digest   = MD5( username + ':Webshare:' + PŮVODNÍ_heslo ).hexdigest()
"""

import re
import hashlib
import unicodedata
import xbmc
import ssl
import socket

try:
    from urllib.request import urlopen, Request
    from urllib.parse import urlencode
except ImportError:
    from urllib2 import urlopen, Request
    from urllib import urlencode

from md5crypt import md5crypt

WEBSHARE_APIS = ['https://webshare.cz/api', 'https://www.webshare.cz/api']

VIDEO_EXTS = {
    '.mkv', '.mp4', '.avi', '.mov', '.wmv', '.m4v',
    '.ts', '.m2ts', '.flv', '.ogm', '.webm', '.rmvb',
}

MIN_SIZE_MOVIE   = 200 * 1024 * 1024  # 200 MB
MIN_SIZE_EPISODE = 100 * 1024 * 1024  # 100 MB

# ─────────────────────────────────────────────────────────
#  PTT-inspired parser
# ─────────────────────────────────────────────────────────

QUALITY_MAP = [
    (r'(?i)\b(4k|2160p|uhd)\b',         '4K',      1),
    (r'(?i)\b(1080p|fullhd|fhd)\b',     '1080p',   2),
    (r'(?i)\b(bluray|blu-ray|bdrip)\b', 'BluRay',  2),
    (r'(?i)\b(webdl|web-dl)\b',         'WEB-DL',  2),
    (r'(?i)\b(webrip|web-rip)\b',       'WEBRip',  3),
    (r'(?i)\b1080i\b',                  '1080i',   3),
    (r'(?i)\b720p\b',                   '720p',    4),
    (r'(?i)\b(hdtv|hdtvrip)\b',         'HDTV',    4),
    (r'(?i)\b480p\b',                   '480p',    5),
    (r'(?i)\b(576p|dvdrip)\b',          'DVDRip',  6),
    (r'(?i)\b(xvid|divx)\b',            'DVDRip',  6),
    (r'(?i)\b(dvdscr|scr)\b',           'DVDScr',  7),
    (r'(?i)\b(telesync)\b',             'TS',      8),
    (r'(?i)\b(cam|camrip|hdcam)\b',     'CAM',     9),
]


def infer_quality(name, size_bytes=0):
    # Heuristický odhad kvality bez ffprobe.
    # 1) explicitní rozlišení má vždy prioritu
    # 2) pak release/source tag a codec
    # 3) nakonec velikost se zvláštními prahy pro film vs epizodu
    n = (name or '').lower()
    try:
        size_gb = float(size_bytes or 0) / (1024.0 ** 3)
    except Exception:
        size_gb = 0.0

    is_episode = bool(
        re.search(r'(?i)[Ss]\d{1,2}[Ee]\d{1,2}', name or '') or
        re.search(r'(?i)\d{1,2}x\d{1,2}', name or '') or
        re.search(r'(?i)[Ee]p?[\. _]?\d{1,2}', name or '')
    )

    if re.search(r'(cam|camrip|hdcam)', n):
        return 'CAM', 9
    if re.search(r'(telesync|ts)', n):
        return 'TS', 8
    if re.search(r'(dvdscr|scr)', n):
        return 'DVDScr', 7
    if re.search(r'(480p|576p|dvdrip|xvid|divx)', n):
        return 'DVDRip', 6

    if re.search(r'(4k|2160p|uhd)', n):
        return '4K', 1
    if re.search(r'(1080p|fullhd|fhd)', n):
        return '1080p', 2
    if re.search(r'1080i', n):
        return '1080i', 3
    if re.search(r'(720p|1280x720)', n):
        return '720p', 4
    if re.search(r'(hdtv|hdtvrip)', n):
        return 'HDTV', 4

    has_uhd_hint = bool(re.search(r'(remux|uhd\.?bluray|bluray\.uhd|hdr10\+?|dolby\.?vision|dv|atmos)', n))
    has_modern_codec = bool(re.search(r'(x265|h\.?265|hevc)', n))
    has_good_source = bool(re.search(r'(remux|bluray|blu-ray|bdrip|bdremux|bdmux|webdl|web-dl|webrip|web-rip)', n))
    has_disc_source = bool(re.search(r'(remux|bluray|blu-ray|bdrip|bdremux|bdmux)', n))
    has_web_source = bool(re.search(r'(webdl|web-dl|webrip|web-rip)', n))
    has_hdr = bool(re.search(r'(hdr|hdr10\+?|dolby\.?vision|dv)', n))

    if has_uhd_hint and (has_modern_codec or has_hdr or size_gb >= (5.0 if is_episode else 12.0)):
        return '4K', 1
    if has_good_source and has_modern_codec and has_hdr and size_gb >= (4.0 if is_episode else 8.0):
        return '4K', 1

    if is_episode:
        if has_disc_source:
            if size_gb >= 10.0:
                return '4K', 1
            if size_gb >= 2.2:
                return '1080p', 2
            if size_gb >= 0.9:
                return '720p', 4
        if has_web_source:
            if size_gb >= 4.5 and (has_modern_codec or has_hdr):
                return '4K', 1
            if size_gb >= 1.4:
                return '1080p', 2
            if size_gb >= 0.55:
                return '720p', 4
        if has_modern_codec and size_gb >= 1.2:
            return '1080p', 2
        if size_gb >= 1.8:
            return '1080p', 2
        if size_gb >= 0.7:
            return '720p', 4
    else:
        if has_disc_source:
            if size_gb >= 20.0:
                return '4K', 1
            if size_gb >= 4.5:
                return '1080p', 2
            if size_gb >= 1.8:
                return '720p', 4
        if has_web_source:
            if size_gb >= 8.0 and (has_modern_codec or has_hdr):
                return '4K', 1
            if size_gb >= 3.5:
                return '1080p', 2
            if size_gb >= 1.4:
                return '720p', 4
        if has_modern_codec and has_hdr and size_gb >= 6.0:
            return '4K', 1
        if has_modern_codec and size_gb >= 3.0:
            return '1080p', 2
        if size_gb >= 5.0:
            return '1080p', 2
        if size_gb >= 2.0:
            return '720p', 4

    return '', 99


LANG_MAP = [
    (r'(?i)\bcz[\. _\-]?dub(bing)?\b',          'CZ dabing'),
    (r'(?i)\b(czech|cestina|cesky)\b',           'CZ'),
    (r'(?i)(^|[\.\- _(])cz([\.\- _)|$])',        'CZ'),
    (r'(?i)\bsk[\. _\-]?dub(bing)?\b',           'SK dabing'),
    (r'(?i)\b(slovak|slovencina|slovensky)\b',   'SK'),
    (r'(?i)(^|[\.\- _(])sk([\.\- _)|$])',        'SK'),
    (r'(?i)\b(eng|english)\b',                   'EN'),
    (r'(?i)(^|[\.\- _(])en([\.\- _)|$])',        'EN'),
    (r'(?i)\b(ger|german|deutsch)\b',            'DE'),
    (r'(?i)\b(pol|polish|polski)\b',             'PL'),
    (r'(?i)\b(hun|hungarian|magyar)\b',          'HU'),
    (r'(?i)\b(rus|russian)\b',                   'RU'),
    (r'(?i)\b(multi|multilang|multisub)\b',      'MULTI'),
    (r'(?i)\b(titulky|subtitles?|subs?)\b',      'titulky'),
]

AUDIO_MAP = [
    (r'(?i)\b(dolby.?atmos|atmos)\b',       'Atmos'),
    (r'(?i)\b(dts.?hd.?ma|dts.?ma)\b',      'DTS-HD MA'),
    (r'(?i)\b(dts.?hd)\b',                  'DTS-HD'),
    (r'(?i)\b(dts)\b',                       'DTS'),
    (r'(?i)\b(truehd)\b',                    'TrueHD'),
    (r'(?i)\b(dd5\.?1|ac3|dolby.digital)\b', 'DD5.1'),
    (r'(?i)\b(aac)\b',                       'AAC'),
    (r'(?i)\b(mp3)\b',                       'MP3'),
]

CODEC_MAP = [
    (r'(?i)\b(x265|h\.?265|hevc)\b', 'H.265'),
    (r'(?i)\b(x264|h\.?264|avc)\b',  'H.264'),
    (r'(?i)\b(av1)\b',               'AV1'),
    (r'(?i)\b(xvid)\b',              'XviD'),
    (r'(?i)\b(divx)\b',              'DivX'),
]


def parse_filename(name, size_bytes=0):
    info = {
        'quality': '', 'quality_rank': 99,
        'langs': [], 'audio': [], 'codec': '',
        'year': '', 'season': None, 'episode': None,
    }
    q_label, q_rank = infer_quality(name, size_bytes)
    if q_label:
        info['quality'] = q_label
        info['quality_rank'] = q_rank
    for pat, lbl, rank in QUALITY_MAP:
        if re.search(pat, name):
            if rank < info['quality_rank']:
                info['quality'] = lbl
                info['quality_rank'] = rank
    for pat, lbl in LANG_MAP:
        if re.search(pat, name) and lbl not in info['langs']:
            info['langs'].append(lbl)
    for pat, lbl in AUDIO_MAP:
        if re.search(pat, name) and lbl not in info['audio']:
            info['audio'].append(lbl)
    for pat, lbl in CODEC_MAP:
        if re.search(pat, name):
            info['codec'] = lbl
            break
    m = re.search(r'\b(19\d{2}|20\d{2})\b', name)
    if m:
        info['year'] = m.group(1)
    # Epizody: S01E01 > 1x01 > E05/ep05
    m = re.search(r'(?i)[Ss](\d{1,2})[Ee](\d{1,2})', name)
    if m:
        info['season'] = int(m.group(1))
        info['episode'] = int(m.group(2))
    else:
        m = re.search(r'(?i)(\d{1,2})x(\d{1,2})', name)
        if m:
            info['season'] = int(m.group(1))
            info['episode'] = int(m.group(2))
        else:
            m = re.search(r'(?i)\b[Ee]p?[\. _]?(\d{1,2})\b', name)
            if m:
                info['episode'] = int(m.group(1))
    return info


def _norm(s):
    try:
        if isinstance(s, bytes):
            s = s.decode('utf-8')
        n = unicodedata.normalize('NFD', s)
        out = u''.join(c for c in n if unicodedata.category(c) != 'Mn')
        return re.sub(r'[^a-z0-9 ]', ' ', out.lower()).strip()
    except Exception:
        return s.lower()


def _title_matches(title, filename):
    """
    Tolerantnější porovnání názvu titulu se jménem souboru.
    Bere v úvahu i aliasy v hranatých závorkách a kombinaci CZ + EN názvu.
    """
    def _nfn(s):
        try:
            n = unicodedata.normalize('NFD', str(s))
            n = u''.join(c for c in n if unicodedata.category(c) != 'Mn').lower()
            return re.sub(r'\s+', ' ', re.sub(r'[\[\]\(\){}._\-:;,+]+', ' ', n)).strip()
        except:
            return str(s).lower().strip()

    fn = _nfn(filename)
    t  = _nfn(title)
    if not t or not fn:
        return False
    if t == fn:
        return True

    m = re.search(r'\b[Ss]\d{1,2}[Ee]\d{1,2}\b|\b(19|20)\d{2}\b', fn)
    fn_title = fn[:m.start()].strip() if m else fn
    fn_all = fn_title + ' ' + fn

    t_words = _sig_words(t)
    if not t_words:
        return False

    if len(t_words) == 1:
        return bool(re.search(r'\b' + re.escape(t_words[0]) + r'\b', fn_all))

    hits = sum(1 for w in t_words if re.search(r'\b' + re.escape(w) + r'\b', fn_all))
    ratio = hits / float(len(t_words))
    if len(t_words) == 2:
        return hits == 2 or ratio >= 0.8
    return ratio >= 0.75


def format_size(b):
    try:
        b = int(b)
    except (ValueError, TypeError):
        return ''
    if b >= 1024**3:
        return '%.1f GB' % (b / 1024.0**3)
    if b >= 1024**2:
        return '%.0f MB' % (b / 1024.0**2)
    return '%.0f KB' % (b / 1024.0)


def build_file_label(name, size_bytes, positive=0):
    info = parse_filename(name)
    parts = []
    if info['quality']:
        parts.append('[COLOR yellow][%s][/COLOR]' % info['quality'])
    if info['langs']:
        parts.append('[COLOR cyan][%s][/COLOR]' % ' | '.join(info['langs']))
    if info['audio']:
        parts.append('[COLOR green][%s][/COLOR]' % ' | '.join(info['audio']))
    if info['codec']:
        parts.append('[COLOR gray][%s][/COLOR]' % info['codec'])
    label = '  '.join(parts) if parts else name
    sz = format_size(size_bytes)
    if sz:
        label += '  [COLOR white]%s[/COLOR]' % sz
    if positive and int(positive) > 0:
        label += '  [COLOR orange]♥%d[/COLOR]' % int(positive)
    return label


# ─────────────────────────────────────────────────────────
#  Webshare API
# ─────────────────────────────────────────────────────────

def _post(endpoint, data, token=''):
    last_error = None
    payload = dict(data)
    if token:
        payload['wst'] = token

    for api_base in WEBSHARE_APIS:
        url = '%s/%s/' % (api_base, endpoint)
        for timeout in (10, 20, 30):
            try:
                body = urlencode(payload)
                if isinstance(body, str):
                    body = body.encode('utf-8')

                headers = {
                    'Content-Type':     'application/x-www-form-urlencoded; charset=UTF-8',
                    'X-Requested-With': 'XMLHttpRequest',
                    'Accept':           'text/xml; charset=UTF-8',
                    'User-Agent':       'Kodi KinoStream/2.4.10',
                    'Connection':       'close',
                    'Host':             'webshare.cz',
                }

                # 1) standard TLS
                req = Request(url, body, headers)
                try:
                    return urlopen(req, timeout=timeout).read().decode('utf-8')
                except Exception as e:
                    last_error = e

                # 2) unverified TLS fallback (pomáhá na některých Kodi/Win instalacích)
                try:
                    req = Request(url, body, headers)
                    ctx = ssl._create_unverified_context()
                    return urlopen(req, timeout=timeout, context=ctx).read().decode('utf-8')
                except Exception as e:
                    last_error = e

            except Exception as e:
                last_error = e

        xbmc.log('WS [%s] host failed: %s (%s)' % (endpoint, api_base, last_error), xbmc.LOGWARNING)

    xbmc.log('WS [%s] error: %s' % (endpoint, last_error), xbmc.LOGERROR)
    return ''

def _x(xml, tag):
    m = re.search(r'<%s>(.*?)</%s>' % (tag, tag), xml, re.DOTALL)
    return m.group(1).strip() if m else ''


# ─────────────────────────────────────────────────────────
#  LOGIN — přesně dle kodi-czsk/yawsp/wsc
# ─────────────────────────────────────────────────────────

def login(username, password):
    """
    Přihlásí se k Webshare.cz.

    Přesný postup dle funkčních pluginů (kodi-czsk, yawsp, wsc):
      1. Získej salt z API
      2. password_hash = SHA1( md5crypt(password, salt) ).hexdigest()
      3. digest = MD5( username + ':Webshare:' + PŮVODNÍ_heslo ).hexdigest()
      4. Pošli login s oběma

    KLÍČOVÝ DETAIL: digest se počítá z PŮVODNÍHO hesla, ne z hashe!
    """
    # 1. Získej salt
    xml = _post('salt', {'username_or_email': username})
    if not xml:
        xbmc.log('WS login: žádná odpověď pro salt', xbmc.LOGERROR)
        return None
    if _x(xml, 'status') != 'OK':
        xbmc.log('WS login: salt status=%s msg=%s' % (_x(xml, 'status'), _x(xml, 'message')), xbmc.LOGERROR)
        return None

    salt = _x(xml, 'salt')
    if not salt:
        xbmc.log('WS login: prázdný salt', xbmc.LOGERROR)
        return None

    xbmc.log('WS: salt OK = "%s"' % salt, xbmc.LOGDEBUG)

    # 2. Hash hesla: SHA1( md5crypt(password, salt).encode('utf-8') )
    # md5crypt vraci STRING "$1$salt$hash" — stejne jako SCC unix_md5_crypt
    # SHA1 se pocita z UTF-8 encoded stringu — identicky s SCC kodiutils.hash_password
    try:
        crypt_str     = md5crypt(password, salt)  # returns STRING
        password_hash = hashlib.sha1(crypt_str.encode('utf-8')).hexdigest()
    except Exception as e:
        xbmc.log('WS: chyba pri hashovani hesla: %s' % e, xbmc.LOGERROR)
        return None

    # 3. Digest: MD5(username + ':Webshare:' + PŮVODNÍ heslo)
    #    POZOR: používáme PŮVODNÍ heslo, ne zahashované!
    try:
        digest_str = '%s:Webshare:%s' % (username, password)
        digest = hashlib.md5(digest_str.encode('utf-8')).hexdigest()
    except Exception as e:
        xbmc.log('WS: chyba při digest: %s' % e, xbmc.LOGERROR)
        return None

    xbmc.log('WS: hash OK, odesílám login...', xbmc.LOGDEBUG)

    # 4. Login
    xml = _post('login', {
        'username_or_email': username,
        'password':          password_hash,
        'digest':            digest,
        'keep_logged_in':    1,
    })

    if not xml:
        xbmc.log('WS login: žádná odpověď', xbmc.LOGERROR)
        return None
    if _x(xml, 'status') != 'OK':
        msg = _x(xml, 'message')
        xbmc.log('WS login FAILED: %s' % msg, xbmc.LOGERROR)
        return None

    token = _x(xml, 'token')
    if not token:
        xbmc.log('WS login: prázdný token', xbmc.LOGERROR)
        return None

    xbmc.log('WS: přihlášení OK, token=%s...' % token[:10], xbmc.LOGDEBUG)
    return token


# ─────────────────────────────────────────────────────────
#  Raw search
# ─────────────────────────────────────────────────────────

def _raw_search(token, query, limit=50, sort='best'):
    xml = _post('search', {
        'what':     query,
        'category': 'video',
        'sort':     sort,
        'limit':    limit,
        'offset':   0,
    }, token=token)

    if not xml or _x(xml, 'status') != 'OK':
        return []

    files = []
    for block in re.findall(r'<file>(.*?)</file>', xml, re.DOTALL):
        ident = _x(block, 'ident')
        name  = _x(block, 'name')
        if not ident or not name:
            continue
        if _x(block, 'password') == '1':
            continue
        ext = ('.' + name.rsplit('.', 1)[-1]).lower() if '.' in name else ''
        if ext not in VIDEO_EXTS:
            continue
        sz_s = _x(block, 'size')
        sz   = int(sz_s) if sz_s.isdigit() else 0
        pos  = _x(block, 'positive')
        neg  = _x(block, 'negative')
        fi   = parse_filename(name)
        fi.update({
            'ident':    ident,
            'name':     name,
            'size':     sz,
            'size_str': format_size(sz),
            'positive': int(pos) if pos.isdigit() else 0,
            'negative': int(neg) if neg.isdigit() else 0,
        })
        files.append(fi)
    return files


# ─────────────────────────────────────────────────────────
#  Smart search — Krok A (dotazy) + Krok B (The Bouncer)
# ─────────────────────────────────────────────────────────

def _dedupe(seq):
    out = []
    seen = set()
    for item in seq:
        key = (item or '').strip().lower()
        if not key or key in seen:
            continue
        seen.add(key)
        out.append(item.strip())
    return out


def _search_title_forms(title):
    title = (title or '').strip()
    if not title:
        return []

    forms = [title]
    clean = re.sub(r'\s+', ' ', re.sub(r'[._:;\-]+', ' ', title)).strip()
    if clean and clean.lower() != title.lower():
        forms.append(clean)

    ascii_clean = _norm(title).title()
    if ascii_clean and ascii_clean.lower() not in [f.lower() for f in forms]:
        forms.append(ascii_clean)

    words = [w for w in re.findall(r'[a-z0-9]+', _norm(title))
             if len(w) > 2 and w not in ('the', 'and', 'with', 'from')]
    if len(words) >= 2:
        forms.append(' '.join(words[:4]).title())

    return _dedupe(forms)


def _build_queries(title, year='', original_title=''):
    queries = []
    for variant in _search_title_forms(title):
        if year:
            queries.append('%s %s' % (variant, year))
        queries.append(variant)

    if original_title and _norm(original_title) != _norm(title):
        for variant in _search_title_forms(original_title):
            if year:
                queries.append('%s %s' % (variant, year))
            queries.append(variant)

    return _dedupe(queries)[:8]




def _sig_words(s):
    return [w for w in re.findall(r'[a-z0-9]+', _norm(s))
            if len(w) > 2 and w not in ('the','and','with','from','movie','film')]


def _loose_title_score(title, filename):
    fn = _norm(filename)
    t = _norm(title)
    if not fn or not t:
        return 0.0
    m = re.search(r'\b[Ss]\d{1,2}[Ee]\d{1,2}\b|\b(19|20)\d{2}\b', fn)
    fn_title = (fn[:m.start()].strip() if m else fn)
    fn_all = fn_title + ' ' + fn
    tw = _sig_words(t)
    if not tw:
        return 0.0
    hits = sum(1 for w in tw if re.search(r'\b' + re.escape(w) + r'\b', fn_all))
    score = hits / float(len(tw))
    if tw and re.search(r'\b' + re.escape(tw[0]) + r'\b', fn_all):
        score += 0.1
    return min(score, 1.0)


def _fallback_candidates(files, titles, year=''):
    picked = []
    for f in files:
        best = 0.0
        for t in titles:
            best = max(best, _loose_title_score(t, f.get('name','')))
        if best < 0.6:
            continue
        if year and f.get('year') and str(f.get('year')).isdigit():
            try:
                if abs(int(f['year']) - int(year)) > 1:
                    continue
            except Exception:
                pass
        f['_match_score'] = best
        picked.append(f)
    picked.sort(key=lambda x: (-x.get('_match_score', 0), x.get('quality_rank', 99), -x.get('size', 0)))
    return picked[:15]

def _bouncer(files, titles, year, min_size):
    good = []
    for f in files:
        if f['size'] < min_size:
            continue
        if not any(_title_matches(t, f['name']) for t in titles):
            xbmc.log('WS filter: neshoda názvu [%s]' % f['name'], xbmc.LOGDEBUG)
            continue
        if year and f.get('year') and f['year'] != str(year):
            xbmc.log('WS filter: špatný rok %s!=%s [%s]' % (f['year'], year, f['name']), xbmc.LOGDEBUG)
            continue
        good.append(f)
    return good


def _sort_files(files):
    files.sort(key=lambda x: (
        x.get('quality_rank', 99),
        -(x.get('positive', 0) - x.get('negative', 0)),
        -x.get('size', 0)
    ))
    return files


def file_info(token, ident):
    """Best-effort metadata fetch for a specific Webshare file.
    Public API docs mention file_info; different installs may expose slightly
    different XML fields, so this parser is intentionally tolerant.
    """
    xml = _post('file_info', {'ident': ident}, token=token)
    if not xml or _x(xml, 'status') not in ('OK', ''):
        return {}
    meta = {}
    for tag in ('name', 'description', 'tags', 'media', 'audio', 'subtitles', 'subtitle', 'language', 'languages'):
        val = _x(xml, tag)
        if val:
            meta[tag] = val
    # collect raw text for downstream parsers
    raw_parts = [meta.get(k, '') for k in ('description', 'tags', 'media', 'audio', 'subtitles', 'subtitle', 'language', 'languages') if meta.get(k)]
    if raw_parts:
        meta['meta_text'] = ' | '.join(raw_parts)
    audio_langs = []
    subtitle_langs = []
    raw = (meta.get('meta_text', '') + ' ' + meta.get('description', '')).lower()
    lang_patterns = [
        ('CZ', r'czech|cesk[yaé]|\bcz\b'),
        ('SK', r'slovak|slovensk|\bsk\b'),
        ('ENG', r'english|\beng\b|\ben\b'),
        ('DE', r'german|deutsch|\bger\b|\bde\b'),
        ('ESP', r'spanish|espanol|español|\besp\b|\bes\b'),
        ('FR', r'french|\bfr\b'),
        ('ITA', r'italian|\bita\b|\bit\b'),
        ('PL', r'polish|polski|\bpl\b'),
        ('HU', r'hungarian|magyar|\bhu\b'),
        ('RU', r'russian|\brus\b|\bru\b'),
    ]
    for code, pat in lang_patterns:
        if re.search(r'(audio|dab|dub|dabing)[^<]{0,20}(?:' + pat + ')', raw, re.I) or re.search(r'(?:' + pat + ')[^<]{0,20}(audio|dab|dub|dabing)', raw, re.I):
            audio_langs.append(code)
        if re.search(r'(sub|subs|subtitle|titulky)[^<]{0,20}(?:' + pat + ')', raw, re.I) or re.search(r'(?:' + pat + ')[^<]{0,20}(sub|subs|subtitle|titulky)', raw, re.I):
            subtitle_langs.append(code)
    if audio_langs:
        meta['audio_langs'] = list(dict.fromkeys(audio_langs))
    if subtitle_langs:
        meta['subtitle_langs'] = list(dict.fromkeys(subtitle_langs))
    return meta


def enrich_file_infos(token, files, limit=8):
    if not token or not files:
        return files
    for f in files[:max(0, int(limit))]:
        ident = f.get('ident')
        if not ident:
            continue
        try:
            meta = file_info(token, ident)
        except Exception as e:
            xbmc.log('WS file_info [%s] failed: %s' % (ident, e), xbmc.LOGWARNING)
            continue
        if not meta:
            continue
        f.update({k: v for k, v in meta.items() if v})
    return files


def search_for_title(token, title, year='', original_title='', limit=50):
    """
    Hledá filmy na Webshare podle názvu.
    Spustí více dotazů (CZ + EN + rok), výsledky sloučí a přefiltruje.
    """
    all_files = {}
    for q in _build_queries(title, year, original_title):
        try:
            for f in _raw_search(token, q, limit=limit):
                if f['ident'] not in all_files:
                    all_files[f['ident']] = f
        except Exception as e:
            xbmc.log('WS search [%s]: %s' % (q, e), xbmc.LOGERROR)

    if not all_files:
        return []

    xbmc.log('WS search_for_title: %d raw results for "%s" / "%s"' % (
        len(all_files), title, original_title), xbmc.LOGINFO)

    # Všechny varianty názvů pro matching (CZ + EN)
    titles = [title]
    if original_title and _norm(original_title) != _norm(title):
        titles.append(original_title)

    # Krok 1: přísný filtr — název + rok + min. velikost
    filtered = _bouncer(list(all_files.values()), titles, year, MIN_SIZE_MOVIE)

    # Krok 2: bez omezení velikosti
    if not filtered:
        filtered = _bouncer(list(all_files.values()), titles, year, min_size=0)
        if filtered:
            xbmc.log('WS search_for_title: fallback bez min_size, %d vysledku' % len(filtered), xbmc.LOGINFO)

    # Krok 3: bez roku (rok mohl být špatně parsován)
    if not filtered:
        filtered = _bouncer(list(all_files.values()), titles, year='', min_size=0)
        if filtered:
            xbmc.log('WS search_for_title: fallback bez roku, %d vysledku' % len(filtered), xbmc.LOGINFO)

    if not filtered:
        filtered = _fallback_candidates(list(all_files.values()), titles, year)
        if filtered:
            xbmc.log('WS search_for_title: fallback tolerantni matcher, %d vysledku' % len(filtered), xbmc.LOGINFO)

    if not filtered:
        xbmc.log('WS search_for_title: 0 vysledku po filtru pro "%s"' % title, xbmc.LOGWARNING)
        return []

    xbmc.log('WS search_for_title: %d/%d po filtru pro "%s"' % (
        len(filtered), len(all_files), title), xbmc.LOGINFO)
    filtered = _sort_files(filtered)
    enrich_file_infos(token, filtered, limit=min(8, len(filtered)))
    return filtered


def search_for_episode(token, title, season, episode, year='', original_title='', limit=50):
    all_files = {}
    s_str = 'S%02dE%02d' % (season, episode)
    x_str = '%dx%02d'    % (season, episode)

    base_titles = [title]
    if original_title and original_title.lower() != title.lower():
        base_titles.append(original_title)

    for t in base_titles[:2]:
        for marker in [s_str, x_str]:
            q = '%s %s' % (t, marker)
            try:
                for f in _raw_search(token, q, limit=limit):
                    if f['ident'] not in all_files:
                        all_files[f['ident']] = f
            except Exception as e:
                xbmc.log('WS ep search [%s]: %s' % (q, e), xbmc.LOGERROR)

    if not all_files:
        return []

    filtered = []
    for f in all_files.values():
        if f['size'] < MIN_SIZE_EPISODE:
            continue
        fs = f.get('season')
        fe = f.get('episode')
        if fs is not None and fs != season:
            continue
        if fe is not None and fe != episode:
            continue
        if fs is None and fe is None:
            if not (re.search(r'(?i)[Ss]%02d[Ee]%02d' % (season, episode), f['name']) or
                    re.search(r'(?i)%dx%02d' % (season, episode), f['name'])):
                continue
        filtered.append(f)

    return _sort_files(filtered)


def get_file_link(token, ident):
    xml = _post('file_link', {
        'ident':         ident,
        'download_type': 'video_stream',
        'force_https':   1,
    }, token=token)
    if not xml or _x(xml, 'status') != 'OK':
        xbmc.log('WS file_link [%s] failed: %s' % (ident, _x(xml, 'message')), xbmc.LOGERROR)
        return None
    return _x(xml, 'link') or None
