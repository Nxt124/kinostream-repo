# -*- coding: utf-8 -*-
"""
Kino Stream v2.1.0 — Kodi plugin
Menu identické s Enigma2 provider.py (legacy content provider)
"""

import sys, os, re, json, time as _time_mod

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

try:
    import xbmcvfs
    _translate_path = xbmcvfs.translatePath
except (ImportError, AttributeError):
    _translate_path = xbmc.translatePath

try:
    from urllib.parse import parse_qsl, urlencode, unquote_plus
    from urllib.request import Request, urlopen
except ImportError:
    from urlparse import parse_qsl
    from urllib import urlencode
    from urllib2 import Request, urlopen

import tmdb_api
import webshare
from resources.lib.download_manager import DownloadManager, DownloadError
from resources.lib import download_store
from resources.lib.ui import list_downloaded_files, show_downloaded_item_actions

# ══════════════════════════════════════════════════════════════════════════════
#  INICIALIZACE
# ══════════════════════════════════════════════════════════════════════════════

addon        = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])
addon_url    = sys.argv[0]
ADDON_DIR    = _translate_path(addon.getAddonInfo('path'))

profile_path = _translate_path(addon.getAddonInfo('profile'))
if not os.path.exists(profile_path):
    try: os.makedirs(profile_path)
    except: pass

WATCHED_FILE = os.path.join(profile_path, 'watched.json')
RECENT_FILE  = os.path.join(profile_path, 'recent_played.json')
FAVORITES_FILE = os.path.join(profile_path, 'favorites.json')
TOKEN_FILE   = os.path.join(profile_path, 'ws_token.json')
ALPHABET_CACHE_FILE = os.path.join(profile_path, 'alphabet_cache.json')
SEARCH_CACHE_FILE = os.path.join(profile_path, 'search_cache.json')
PROBE_CACHE_FILE = os.path.join(profile_path, 'probe_cache.json')
PROBE_CACHE_TTL = 12 * 60 * 60
TMDB_KEY     = addon.getSetting('tmdb_api_key') or 'a9d851cb36fd8287fed226766d7f01ab'
SEARCH_CACHE_TTL = 6 * 60 * 60
FEEDBACK_URL = 'https://script.google.com/macros/s/AKfycbxIuaLemJJdP_w5MMw6IYq60uINXDDjDM1kptCcPKqOYg-8hpWtKiPaoGdelNx-jDZl/exec'

# ══════════════════════════════════════════════════════════════════════════════
#  CONSTANTS — identické s provider.py
# ══════════════════════════════════════════════════════════════════════════════

COUNTRY_NAMES = {
    'US':'USA','GB':'Velka Britanie','CZ':'Ceska republika','SK':'Slovensko',
    'DE':'Nemecko','FR':'Francie','IT':'Italie','ES':'Spanelsko','PL':'Polsko',
    'RU':'Rusko','AU':'Australie','CA':'Kanada','JP':'Japonsko','KR':'Jizni Korea',
    'CN':'Cina','IN':'Indie','SE':'Svedsko','NO':'Norsko','DK':'Dansko',
    'FI':'Finsko','NL':'Nizozemsko','BE':'Belgie','AT':'Rakousko','CH':'Svycarsko',
    'HU':'Madarsko','BR':'Brazilie','MX':'Mexiko','AR':'Argentina','ZA':'Jizni Afrika',
    'IE':'Irsko','PT':'Portugalsko','TR':'Turecko','IL':'Izrael','TH':'Thajsko',
}
FEATURED_COUNTRIES_MOVIE  = ['US','GB','CZ','SK','DE','FR','IT','ES','AU','CA','JP','KR','RU','PL','SE','DK','NO']
FEATURED_COUNTRIES_TVSHOW = ['US','GB','CZ','SK','DE','FR','KR','JP','SE','DK','NO','AU','CA','RU','PL']

QUALITY_PATTERN = (
    r'\b(720p|1080p|2160p|4K|UHD|BluRay|BRRip|WEBRip|HDTV|WEB-DL|DVDRip|'
    r'x264|x265|HEVC|H\.264|H\.265|AAC|AC3|DTS|'
    r'CZ|SK|EN|MULTI|DUAL|SUB|DUBBED|'
    r'KINORIP|CAMRIP|TELESYNC|TS|CAM|SCREENER|'
    r'REMUX|PROPER|REPACK|UNRATED|EXTENDED|'
    r'DD5\.1|TrueHD|ATMOS)\b'
)

# ══════════════════════════════════════════════════════════════════════════════
#  HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _norm(s):
    """Normalizuje string pro porovnání — odstraní diakritiku, lowercase."""
    import unicodedata
    try:
        if isinstance(s, bytes): s = s.decode('utf-8')
        n = unicodedata.normalize('NFD', s)
        return u''.join(c for c in n if unicodedata.category(c) != 'Mn').lower().strip()
    except:
        return (s or '').lower().strip()


def _split_search_keyword(keyword):
    keyword = re.sub(r'\s+', ' ', (keyword or '').strip())
    if not keyword:
        return '', ''
    m = re.search(r'\b(19\d{2}|20\d{2})\b', keyword)
    year = m.group(1) if m else ''
    if year:
        stripped = re.sub(r'\b%s\b' % re.escape(year), ' ', keyword)
        stripped = re.sub(r'\s+', ' ', stripped).strip()
        if stripped:
            return stripped, year
    return keyword, ''






def _load_search_cache():
    try:
        if os.path.exists(SEARCH_CACHE_FILE):
            with open(SEARCH_CACHE_FILE, 'r', encoding='utf-8') as fh:
                return json.load(fh)
    except:
        pass
    return {}


def _save_search_cache(data):
    try:
        with open(SEARCH_CACHE_FILE, 'w', encoding='utf-8') as fh:
            json.dump(data, fh)
    except:
        pass


def _search_cache_key(title, year='', orig_title=''):
    return '%s|%s|%s' % (_norm(title or ''), str(year or ''), _norm(orig_title or ''))


def _get_cached_movie_files(title, year='', orig_title=''):
    key = _search_cache_key(title, year, orig_title)
    cache = _load_search_cache()
    item = cache.get(key)
    if not isinstance(item, dict):
        return []
    ts = int(item.get('ts') or 0)
    if not ts or (_time_mod.time() - ts) > SEARCH_CACHE_TTL:
        cache.pop(key, None)
        _save_search_cache(cache)
        return []
    files = item.get('files') or []
    return files if isinstance(files, list) else []


def _set_cached_movie_files(title, year='', orig_title='', files=None):
    key = _search_cache_key(title, year, orig_title)
    cache = _load_search_cache()
    cache[key] = {'ts': int(_time_mod.time()), 'files': files or []}
    if len(cache) > 120:
        ordered = sorted(cache.items(), key=lambda kv: kv[1].get('ts', 0), reverse=True)[:120]
        cache = dict(ordered)
    _save_search_cache(cache)


def _load_probe_cache():
    try:
        if os.path.exists(PROBE_CACHE_FILE):
            with open(PROBE_CACHE_FILE, 'r', encoding='utf-8') as fh:
                return json.load(fh)
    except:
        pass
    return {}


def _save_probe_cache(cache):
    try:
        with open(PROBE_CACHE_FILE, 'w', encoding='utf-8') as fh:
            json.dump(cache or {}, fh, ensure_ascii=False)
    except:
        pass

def _clean_title_tokens(title):
    title_n = _norm(title or '')
    return [w for w in re.findall(r'[a-z0-9]+', title_n) if len(w) > 1]


def _movie_title_part(name):
    fn = _norm((name or '').replace('.', ' ').replace('_', ' ').replace('-', ' '))
    m = re.search(r'\b[Ss]\d{1,2}[Ee]\d{1,2}\b|\b\d{1,2}x\d{1,2}\b|\b(19|20)\d{2}\b', fn)
    return (fn[:m.start()] if m else fn).strip()


def _filter_movie_files_precise(files, title, year='', orig_title=''):
    """Prísnější filtr filmů — vyhodí epizody/serialy a nesouvisející releasy."""
    if not files:
        return []

    titles = []
    for raw in [title, orig_title]:
        n = _norm(raw or '')
        if n and n not in titles:
            titles.append(n)
    if not titles:
        return files

    wanted_year = str(year) if year else ''
    primary_words = set(_clean_title_tokens(title))
    orig_words = set(_clean_title_tokens(orig_title))
    title_word_pool = primary_words | orig_words
    kept = []

    for f in files:
        name = f.get('name', '')
        if not name:
            continue
        info = webshare.parse_filename(name)
        part = _movie_title_part(name)
        part_words = set(_clean_title_tokens(part))
        name_words = set(_clean_title_tokens(name))

        # Pryc s epizodami / serialovymi releasy
        if info.get('season') is not None or info.get('episode') is not None:
            continue
        if re.search(r'(?i)\b[Ss]\d{1,2}[Ee]\d{1,2}\b|\b\d{1,2}x\d{1,2}\b', name):
            continue

        # Rok musi sedet, pokud je v souboru detekovany
        if wanted_year and info.get('year') and str(info.get('year')) != wanted_year:
            continue

        # Musi sedet aspon jeden z titulů dost prísne
        if not any(webshare._title_matches(t, name) for t in titles):
            continue

        # U vice-slovnych názvů vyzaduj aspon 60 % slov v title casti
        if len(primary_words) >= 2:
            overlap = len(primary_words & (part_words or name_words))
            if overlap / float(len(primary_words)) < 0.60:
                continue

        # Penalizace dlouhych cizich nazvu — title cast nesmi byt výrazně delší než hledaný titul
        if primary_words and part_words:
            extra = len(part_words - title_word_pool)
            if extra >= max(3, len(primary_words)):
                continue

        kept.append(f)

    # Když je filtr až moc prísný, vrat alespon title-matching bez epizod
    if not kept:
        relaxed = []
        for f in files:
            name = f.get('name', '')
            info = webshare.parse_filename(name)
            if info.get('season') is not None or info.get('episode') is not None:
                continue
            if any(webshare._title_matches(t, name) for t in titles):
                relaxed.append(f)
        return relaxed

    return kept


def _relaxed_title_overlap(name, wanted_titles):
    """Fallback score for broad Webshare matches. Higher is better."""
    part = _movie_title_part(name)
    part_words = set(_clean_title_tokens(part)) or set(_clean_title_tokens(name))
    if not part_words:
        return 0.0
    best = 0.0
    for t in wanted_titles or []:
        t_words = set(_clean_title_tokens(t))
        if not t_words:
            continue
        overlap = len(t_words & part_words) / float(len(t_words))
        best = max(best, overlap)
    return best


def _add_movie_list_toggle(title, year='', orig_title='', tmdb_id='', poster='', backdrop=''):
    params = dict(media_type='movie', tmdb_id=tmdb_id, title=title, year=year,
                  orig_title=orig_title, poster=poster, backdrop=backdrop)
    exists = _favorite_exists('movie', tmdb_id, title)
    label = '[B]Odebrat z Mého seznamu[/B]' if exists else '[B]Pridat do Mého seznamu[/B]'
    li = xbmcgui.ListItem(label)
    if poster:
        li.setArt({'thumb': poster, 'poster': poster, 'fanart': backdrop or poster, 'icon': poster})
    _set_info(li, {'title': label, 'plot': 'Ulozi tento film do sekce Můj seznam.' if not exists else 'Odebere tento film ze sekce Můj seznam.', 'mediatype': 'video'})
    xbmcplugin.addDirectoryItem(addon_handle, _url(mode='favorite_remove' if exists else 'favorite_add', **params), li, False)


def _add_series_list_toggle(serial_title, serial_year='', serial_original_name='', tmdb_id='', poster='', backdrop=''):
    params = dict(media_type='tvshow', tmdb_id=tmdb_id, title=serial_title, year=serial_year,
                  orig_title=serial_original_name, poster=poster, backdrop=backdrop)
    exists = _favorite_exists('tvshow', tmdb_id, serial_title)
    label = '[B]Odebrat z Mého seznamu[/B]' if exists else '[B]Pridat do Mého seznamu[/B]'
    li = xbmcgui.ListItem(label)
    if poster:
        li.setArt({'thumb': poster, 'poster': poster, 'fanart': backdrop or poster, 'icon': poster})
    _set_info(li, {'title': label, 'plot': 'Ulozi tento serial do sekce Můj seznam.' if not exists else 'Odebere tento serial ze sekce Můj seznam.', 'mediatype': 'video'})
    xbmcplugin.addDirectoryItem(addon_handle, _url(mode='favorite_remove' if exists else 'favorite_add', **params), li, False)

def _quality_badge_code(info):
    q = (info.get('quality') or '').lower()
    if q in ('4k', '2160p', 'uhd') or '4k' in q or '2160' in q:
        return 'UHD'
    if q in ('1080p', '1080i', 'bluray', 'web-dl', 'webrip') or '1080' in q or q in ('bluray', 'blu-ray', 'bdrip', 'web-dl', 'webrip'):
        return 'FHD'
    if q in ('720p', 'hdtv') or '720' in q:
        return 'HD'
    return 'SD'


def _badge_color(code):
    return {
        'UHD': 'red',
        'FHD': 'limegreen',
        'HD': 'deepskyblue',
        'SD': 'gray',
    }.get(code, 'white')


LANG_TOKEN_MAP = [
    ('CZ', (r'czech', r'cesk[yaé]', r'cz', r'cesky', r'cestina')),
    ('SK', (r'slovak', r'slovensk', r'sk')),
    ('ENG', (r'english', r'eng', r'en')),
    ('DE', (r'german', r'deutsch', r'ger', r'de')),
    ('ESP', (r'spanish', r'espanol', r'español', r'esp', r'es')),
    ('FR', (r'french', r'fra', r'fr')),
    ('ITA', (r'italian', r'ita', r'it')),
    ('PL', (r'polish', r'polski', r'pl')),
    ('HU', (r'hungarian', r'magyar', r'hu')),
    ('RU', (r'russian', r'rus', r'ru')),
]


def _collect_meta_text(name, info):
    parts = [name or '']
    for key in ('description', 'meta_text', 'raw_meta'):
        val = info.get(key)
        if val:
            parts.append(val)
    for key in ('langs', 'audio'):
        vals = info.get(key) or []
        if vals:
            parts.append(' '.join(vals))
    return ' | '.join(parts)


def _find_lang_code(text, require_context=False):
    txt = (text or '').lower()
    for code, patterns in LANG_TOKEN_MAP:
        for pat in patterns:
            if require_context:
                exprs = [
                    r'(?:dab(?:ing)?|audio|lang)[^a-z0-9]{0,4}%s\b' % pat,
                    r'\b%s[^a-z0-9]{0,4}(?:dab(?:ing)?|audio|lang)\b' % pat,
                    r'(?:tit(?:ulky)?|sub(?:titles?)?)[^a-z0-9]{0,4}%s\b' % pat,
                    r'\b%s[^a-z0-9]{0,4}(?:tit(?:ulky)?|sub(?:titles?)?)\b' % pat,
                ]
                if any(re.search(e, txt, re.I) for e in exprs):
                    return code
            else:
                if re.search(r'\b%s\b' % pat, txt, re.I):
                    return code
    return ''


def _detect_subtitle_lang(name, info):
    text = _collect_meta_text(name, info)
    lower = text.lower()
    if not any(x in lower for x in ('titulky', 'subtitle', 'subtitles', ' subs ', '.sub', '_sub', '-sub', ' cztit', 'cztit', ' subtit')):
        return ''
    # strong explicit patterns
    patterns = [
        ('CZ', r'(?i)(?:cz|czech|cesk[yaé])[ ._:-]{0,3}(?:tit|sub|titulky)'),
        ('CZ', r'(?i)(?:tit|sub|titulky)[ ._:-]{0,3}(?:cz|czech|cesk[yaé])'),
        ('ENG', r'(?i)(?:en|eng|english)[ ._:-]{0,3}(?:tit|sub|titulky)'),
        ('ENG', r'(?i)(?:tit|sub|titulky)[ ._:-]{0,3}(?:en|eng|english)'),
        ('DE', r'(?i)(?:de|ger|german|deutsch)[ ._:-]{0,3}(?:tit|sub|titulky)'),
        ('DE', r'(?i)(?:tit|sub|titulky)[ ._:-]{0,3}(?:de|ger|german|deutsch)'),
        ('ESP', r'(?i)(?:es|esp|spanish|espanol|español)[ ._:-]{0,3}(?:tit|sub|titulky)'),
        ('ESP', r'(?i)(?:tit|sub|titulky)[ ._:-]{0,3}(?:es|esp|spanish|espanol|español)'),
    ]
    for code, pat in patterns:
        if re.search(pat, text):
            return code
    for raw in (info.get('subtitle_langs') or []):
        raw_u = str(raw).upper()
        if raw_u in ('CZ', 'SK', 'ENG', 'DE', 'ESP', 'FR', 'ITA', 'PL', 'HU', 'RU'):
            return raw_u
    code = _find_lang_code(text, require_context=True)
    return code or ''


def _detect_audio_lang(name, info):
    text = _collect_meta_text(name, info)
    langs = [str(x) for x in (info.get('audio_langs') or [])]
    for raw in langs:
        raw_u = raw.upper()
        if raw_u in ('CZ', 'SK', 'ENG', 'DE', 'ESP', 'FR', 'ITA', 'PL', 'HU', 'RU'):
            return raw_u
    lower = text.lower()
    strong = [
        ('CZ', r'(?i)(?:cz|czech|cesk[yaé])[ ._:-]{0,3}(?:dub|dab|dabing|audio)'),
        ('CZ', r'(?i)(?:dub|dab|dabing|audio)[ ._:-]{0,3}(?:cz|czech|cesk[yaé])'),
        ('SK', r'(?i)(?:sk|slovak|slovensk)[ ._:-]{0,3}(?:dub|dab|dabing|audio)'),
        ('ENG', r'(?i)(?:en|eng|english)[ ._:-]{0,3}(?:dub|dab|audio)'),
        ('ENG', r'(?i)(?:dub|dab|audio)[ ._:-]{0,3}(?:en|eng|english)'),
        ('DE', r'(?i)(?:de|ger|german|deutsch)[ ._:-]{0,3}(?:dub|dab|audio)'),
        ('ESP', r'(?i)(?:es|esp|spanish|espanol|español)[ ._:-]{0,3}(?:dub|dab|audio)'),
    ]
    for code, pat in strong:
        if re.search(pat, text):
            return code
    # legacy hints only when explicit subtitle markers are absent
    if 'CZ dabing' in (info.get('langs') or []):
        return 'CZ'
    if 'SK dabing' in (info.get('langs') or []):
        return 'SK'
    # Don't guess from bare CZ/EN; better hide than lie.
    return ''




def _lang_to_code(lang):
    n = _norm(lang or '')
    mapping = {
        'czech': 'CZ', 'cesky': 'CZ', 'cestina': 'CZ', 'ceska': 'CZ', 'cz': 'CZ',
        'slovak': 'SK', 'slovensky': 'SK', 'slovencina': 'SK', 'sk': 'SK',
        'english': 'EN', 'eng': 'EN', 'en': 'EN',
        'german': 'DE', 'deutsch': 'DE', 'ger': 'DE', 'de': 'DE',
        'polish': 'PL', 'polski': 'PL', 'pol': 'PL', 'pl': 'PL',
        'hungarian': 'HU', 'magyar': 'HU', 'hun': 'HU', 'hu': 'HU',
        'russian': 'RU', 'rus': 'RU', 'ru': 'RU',
        'spanish': 'ES', 'spa': 'ES', 'es': 'ES',
        'french': 'FR', 'fre': 'FR', 'fra': 'FR', 'fr': 'FR',
        'italian': 'IT', 'ita': 'IT', 'it': 'IT',
    }
    if n in mapping:
        return mapping[n]
    for key, val in mapping.items():
        if key in n:
            return val
    return (lang or '?')[:8].upper()


def _parse_stream_probe_json(raw):
    audio, subs = [], []
    try:
        payload = json.loads(raw or '{}')
    except:
        payload = {}
    for stream in (payload.get('streams') or []):
        codec_type = (stream.get('codec_type') or '').lower()
        tags = stream.get('tags') or {}
        disp = stream.get('disposition') or {}
        lang = _lang_to_code(tags.get('language') or tags.get('LANGUAGE') or tags.get('title') or '')
        if codec_type == 'audio':
            if lang not in audio:
                audio.append(lang)
        elif codec_type == 'subtitle':
            if disp.get('attached_pic'):
                continue
            if lang not in subs:
                subs.append(lang)
    return {'audio': audio, 'subs': subs}


def _find_ffprobe_cmd():
    try:
        import shutil
        candidates = []
        setting_path = ''
        try:
            setting_path = addon.getSetting('ffprobe_path') or ''
        except:
            setting_path = ''
        if setting_path:
            candidates.append(setting_path)

        for auto in (shutil.which('ffprobe'), shutil.which('ffprobe.exe')):
            if auto and auto not in candidates:
                candidates.append(auto)

        for env_name in ('ProgramFiles', 'ProgramFiles(x86)', 'LocalAppData'):
            env_dir = os.environ.get(env_name)
            if not env_dir:
                continue
            for rel in (
                os.path.join('ffmpeg', 'bin', 'ffprobe.exe'),
                os.path.join('FFmpeg', 'bin', 'ffprobe.exe'),
                os.path.join('ffmpeg-master-latest-win64-gpl', 'bin', 'ffprobe.exe'),
                os.path.join('ffmpeg-master-latest-win64-lgpl', 'bin', 'ffprobe.exe'),
                os.path.join('ffmpeg-master-latest-win32-gpl', 'bin', 'ffprobe.exe'),
                os.path.join('ffmpeg-master-latest-win32-lgpl', 'bin', 'ffprobe.exe'),
            ):
                cand = os.path.join(env_dir, rel)
                if cand not in candidates:
                    candidates.append(cand)

        for cand in ('ffprobe', 'ffprobe.exe', '/usr/bin/ffprobe', '/usr/local/bin/ffprobe'):
            if cand not in candidates:
                candidates.append(cand)

        import subprocess
        for cand in candidates:
            try:
                p = subprocess.Popen([cand, '-version'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                p.communicate(timeout=3)
                if p.returncode == 0:
                    return cand
            except:
                pass
    except Exception as e:
        xbmc.log('Kino Stream ffprobe detection failed: %s' % e, xbmc.LOGDEBUG)
    return ''


def _probe_stream_languages(link):
    try:
        import subprocess
        ffprobe_cmd = _find_ffprobe_cmd()
        if not ffprobe_cmd:
            return None
        p = subprocess.Popen([ffprobe_cmd, '-v', 'error', '-show_streams', '-print_format', 'json', link], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out, err = p.communicate(timeout=20)
        if p.returncode != 0:
            try:
                err_txt = err.decode('utf-8', 'ignore')
            except Exception:
                err_txt = str(err)
            xbmc.log('Kino Stream ffprobe error: %s' % err_txt, xbmc.LOGDEBUG)
            return None
        if hasattr(out, 'decode'):
            out = out.decode('utf-8', 'ignore')
        return _parse_stream_probe_json(out)
    except Exception as e:
        xbmc.log('Kino Stream probe failed: %s' % e, xbmc.LOGDEBUG)
        return None


def _filename_cz_confidence(name):
    n = _norm((name or '').replace('.', ' ').replace('_', ' ').replace('-', ' '))
    score = 0
    if re.search(r'\bcz\s*(dab|dub|dubbing|dabing)\b', n):
        score += 80
    if re.search(r'\b(czech|cestina|cesky|cz)\b', n):
        score += 30
    if re.search(r'\b(titulky|subtitle|subtitles|subs|sub)\b', n):
        score += 10
    if re.search(r'\b(eng|english)\b', n):
        score -= 10
    return max(0, min(score, 100))


def _variant_size_bytes(v):
    try:
        return int(v.get('size_b', 0) or 0)
    except:
        return 0


def _get_probe_result(ident):
    cache = _load_probe_cache()
    item = cache.get(ident) if ident else None
    if isinstance(item, dict):
        ts = int(item.get('ts') or 0)
        if ts and (_time_mod.time() - ts) <= PROBE_CACHE_TTL and isinstance(item.get('result'), dict):
            return item.get('result')

    token = _get_token()
    if not token:
        return None
    link = webshare.get_file_link(token, ident)
    if not link:
        token = _get_token(force=True)
        if token:
            link = webshare.get_file_link(token, ident)
    if not link:
        return None

    result = _probe_stream_languages(link)
    if result:
        cache[ident] = {'ts': int(_time_mod.time()), 'result': result}
        if len(cache) > 200:
            ordered = sorted(cache.items(), key=lambda kv: kv[1].get('ts', 0), reverse=True)[:200]
            cache = dict(ordered)
        _save_probe_cache(cache)
    return result


def _pick_preferred_lang(langs):
    langs = [str(x).upper() for x in (langs or []) if x]
    if not langs:
        return '?'
    if 'CZ' in langs:
        return 'CZ'
    if 'EN' in langs:
        return 'EN'
    if 'ENG' in langs:
        return 'EN'
    return langs[0]


def _pick_probe_candidates(variants):
    try:
        enabled = addon.getSetting('stream_probe_enabled').lower() == 'true'
    except:
        enabled = True
    if not enabled:
        return []
    try:
        top_n = int(addon.getSetting('stream_probe_top_n') or '3')
    except:
        top_n = 3
    try:
        min_conf = int(addon.getSetting('stream_probe_min_confidence') or '50')
    except:
        min_conf = 50

    variants_sorted = sorted(variants or [], key=_source_sort_key)
    preferred = []
    fallback = []
    seen = set()
    for v in variants_sorted:
        ident = v.get('ident', '')
        if not ident or ident in seen:
            continue
        seen.add(ident)
        info = webshare.parse_filename(v.get('name', ''), v.get('size_b', 0))
        if int(info.get('quality_rank', 99) or 99) > 4:
            continue
        conf = _filename_cz_confidence(v.get('name', ''))
        if conf >= min_conf:
            preferred.append(v)
        else:
            fallback.append(v)

    selected = preferred[:top_n]
    if len(selected) < top_n:
        fallback.sort(key=lambda v: (-_variant_size_bytes(v), _source_sort_key(v), (v.get('name') or '').lower()))
        chosen = set(x.get('ident', '') for x in selected)
        for v in fallback:
            ident = v.get('ident', '')
            if ident and ident not in chosen:
                selected.append(v)
                chosen.add(ident)
            if len(selected) >= top_n:
                break
    return selected


def _format_probe_label(probe):
    if not isinstance(probe, dict):
        return ''
    dab = _pick_preferred_lang(probe.get('audio') or [])
    subs = probe.get('subs') or []
    tit = 'žádné' if not subs else _pick_preferred_lang(subs)
    return 'Dab: %s, tit: %s' % (dab, tit)


def _enrich_variants_with_probe(variants):
    probe_map = {}
    for v in _pick_probe_candidates(variants):
        ident = v.get('ident', '')
        if not ident:
            continue
        result = _get_probe_result(ident)
        if result:
            probe_map[ident] = result
    return probe_map

def _source_badge_icon(code):
    return os.path.join(ADDON_DIR, 'resources', 'media', 'badge_%s.png' % code.lower())


def _build_source_label(name, size_bytes=None, size_text='', probe_result=None):
    info = webshare.parse_filename(name or '', size_bytes or 0)
    badge = _quality_badge_code(info)
    parts = []
    sz = size_text or (webshare.format_size(size_bytes) if size_bytes else '')
    if sz:
        parts.append(sz)
    probe_label = _format_probe_label(probe_result)
    if probe_label:
        parts.append(probe_label)
    else:
        dab = _detect_audio_lang(name, info)
        tit = _detect_subtitle_lang(name, info)
        if dab:
            parts.append('DAB: %s' % dab)
        if tit and tit != 'ANO':
            parts.append('TIT: %s' % tit)
    return ' · '.join(parts), badge


def _source_sort_key(v):
    info = webshare.parse_filename(v.get('name', ''), v.get('size_b', 0))
    badge = _quality_badge_code(info)
    audio = _detect_audio_lang(v.get('name', ''), info)
    subs = _detect_subtitle_lang(v.get('name', ''), info)
    quality_rank = {'UHD': 0, 'FHD': 1, 'HD': 2, 'SD': 3}.get(badge, 9)
    audio_rank = {'CZ': 0, 'SK': 1, 'ENG': 2, 'EN': 2, '': 4}.get(audio, 3)
    subs_rank = 0 if subs == 'CZ' else (1 if subs else 2)
    try:
        size_b = int(v.get('size_b', 0) or 0)
    except Exception:
        size_b = 0
    return (quality_rank, audio_rank, subs_rank, -size_b, (v.get('name') or '').lower())


def _rank_tmdb_results(results, keyword, year=''):
    keyword_n = _norm(keyword)
    query_words = [w for w in re.findall(r'[a-z0-9]+', keyword_n) if len(w) > 1]

    def _score(item):
        best = -999
        titles = [item.get('title', ''), item.get('orig_title', '')]
        for raw_title in titles:
            title_n = _norm(raw_title)
            if not title_n:
                continue
            score = 0
            if title_n == keyword_n:
                score += 1000
            elif title_n.startswith(keyword_n):
                score += 700
            elif keyword_n and keyword_n in title_n:
                score += 350

            hits = 0
            for w in query_words:
                if re.search(r'\b%s\b' % re.escape(w), title_n):
                    hits += 1
                    score += 120
            if query_words:
                score += int((hits / float(len(query_words))) * 120)

            extra_words = max(0, len(title_n.split()) - len(query_words))
            score -= min(extra_words * 3, 30)
            best = max(best, score)

        item_year = str(item.get('year', '') or '')
        if year:
            if item_year == str(year):
                best += 180
            elif item_year:
                best -= 90
        return best

    return sorted(results, key=lambda item: (_score(item), item.get('year', '')), reverse=True)




class SourceSelectDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.items_data = kwargs.pop('items_data', [])
        self.poster = kwargs.pop('poster', '')
        self.plot = kwargs.pop('plot', '')
        self.selected = None
        self.focus_mode = 'play'
        super(SourceSelectDialog, self).__init__(*args, **kwargs)

    def _get_selected_position(self):
        try:
            return self.getControl(1000).getSelectedPosition()
        except Exception:
            return -1

    def _get_selected_item(self):
        pos = self._get_selected_position()
        if 0 <= pos < len(self.items_data):
            return self.items_data[pos]
        return None

    def _can_download(self, item):
        return bool(item and item.get('action') == 'play' and item.get('variant'))

    def _fill_list(self):
        src_list = self.getControl(1000)
        src_list.reset()
        for entry in self.items_data:
            label = entry.get('label', '')
            li = xbmcgui.ListItem(label)
            icon = entry.get('icon', '')
            quality = ''
            if icon:
                li.setArt({'icon': icon, 'thumb': icon})
                match = re.search(r'badge_([a-z0-9]+)\.png$', icon, re.I)
                if match:
                    quality = match.group(1).upper()

            parts = [p.strip() for p in label.split('·') if p.strip()]
            primary = parts[0] if parts else label
            secondary = ' · '.join(parts[1:]) if len(parts) > 1 else ''
            row_type = 'source'
            if entry.get('action', '').startswith('favorite_'):
                row_type = 'favorite'
                primary = label
                secondary = 'Rychlá akce pro uložení titulu do seznamu'
                quality = ''

            li.setProperty('ks.primary', primary)
            li.setProperty('ks.secondary', secondary)
            li.setProperty('ks.quality', quality)
            li.setProperty('ks.row_type', row_type)
            li.setProperty('can_download', 'true' if self._can_download(entry) else 'false')
            src_list.addItem(li)

    def _apply_focus_mode(self):
        try:
            self.setProperty('ks.focus_mode', self.focus_mode)
        except Exception:
            pass

    def _update_source_detail(self):
        try:
            item = self._get_selected_item() or {}
            variant = item.get('variant') or {}
            detail = (variant.get('name') or '').strip()
            if not detail:
                detail = (item.get('label') or '').strip()
            if not detail:
                detail = self.plot or ''
            self.getControl(3001).setText(detail)
        except Exception:
            pass

    def _set_focus_mode(self, mode):
        item = self._get_selected_item()
        if mode == 'download' and not self._can_download(item):
            mode = 'play'
        self.focus_mode = mode
        self._apply_focus_mode()
        self._update_source_detail()

    def onInit(self):
        try:
            self.getControl(2001).setImage(self.poster)
        except Exception:
            pass
        self._fill_list()
        self._apply_focus_mode()
        if self.items_data:
            try:
                self.getControl(1000).selectItem(0)
            except Exception:
                pass
            self.setFocus(self.getControl(1000))
        self._update_source_detail()

    def onFocus(self, controlId):
        if controlId == 1001:
            self._set_focus_mode('download')
        else:
            self._set_focus_mode('play')

    def onClick(self, controlId):
        if controlId in (3002, 3999):
            self.close()
            return
        if controlId == 1001:
            item = self._get_selected_item()
            if not item or not self._can_download(item):
                return
            selected = dict(item)
            selected['action'] = 'download'
            self.selected = selected
            self.close()
            return
        if controlId == 1000:
            item = self._get_selected_item()
            if not item:
                return
            self.selected = item
            self.close()
            return

    def onAction(self, action):
        aid = action.getId()
        if aid in (9, 10, 92, 216):
            self.close()
            return

        try:
            cid = self.getFocusId()
        except Exception:
            cid = None

        if cid == 1000:
            if aid == 2:  # right
                item = self._get_selected_item()
                if self._can_download(item):
                    self.setFocus(self.getControl(1001))
                    self._set_focus_mode('download')
                return
            if aid == 1:  # left
                self._set_focus_mode('play')
                return
        elif cid == 1001:
            if aid == 1:  # left
                self.setFocus(self.getControl(1000))
                self._set_focus_mode('play')
                return
            if aid == 2:  # right
                self._set_focus_mode('download')
                return

        try:
            xbmc.sleep(10)
            self._update_source_detail()
        except Exception:
            pass


def _url(**kw):
    safe = {}
    for k, v in kw.items():
        if v is None: v = ''
        if isinstance(v, (list, dict)): v = json.dumps(v, ensure_ascii=False)
        safe[str(k)] = str(v)
    return addon_url + '?' + urlencode(safe)


def _set_info(li, info, is_folder=False):
    """Nastavi video info na ListItem."""
    try:
        tag = li.getVideoInfoTag()
        if info.get('title'):    tag.setTitle(info['title'])
        if info.get('plot'):     tag.setPlot(info['plot'])
        if info.get('year'):
            try: tag.setYear(int(info['year']))
            except: pass
        if info.get('genre'):    tag.setGenres([info['genre']])
        if info.get('director'): tag.setDirectors([info['director']])
        if info.get('duration'):
            try: tag.setDuration(int(info['duration']))
            except: pass
        if info.get('season'):
            try: tag.setSeason(int(info['season']))
            except: pass
        if info.get('episode'):
            try: tag.setEpisode(int(info['episode']))
            except: pass
        if info.get('cast'):
            try: tag.setCast([xbmc.Actor(n,'',0,'') for n in info['cast'][:10]])
            except: pass
        tag.setMediaType(info.get('mediatype','movie'))
    except AttributeError:
        # Kodi 17 fallback
        kodi_info = {k: v for k, v in info.items()
                     if k in ('title','plot','year','genre','director','duration',
                               'cast','season','episode','mediatype')}
        li.setInfo('video', kodi_info)


def _notify(msg, icon=xbmcgui.NOTIFICATION_INFO, ms=3000):
    xbmcgui.Dialog().notification('Kino Stream', msg, icon, ms)


def _jsonrpc_notify_all(sender, message, data_obj):
    try:
        payload = {
            'jsonrpc': '2.0',
            'method': 'JSONRPC.NotifyAll',
            'params': {
                'sender': sender,
                'message': message,
                'data': json.dumps(data_obj, ensure_ascii=False),
            },
            'id': 1,
        }
        xbmc.executeJSONRPC(json.dumps(payload, ensure_ascii=False))
        return True
    except Exception as exc:
        xbmc.log('Kino Stream Up Next notify failed: %s' % exc, xbmc.LOGWARNING)
        return False


def _find_best_episode_variant(serial_title, serial_original_name, season, episode):
    token = _get_token()
    if not token:
        return None
    try:
        variants = webshare.search_for_episode(
            token,
            serial_title or serial_original_name,
            int(season),
            int(episode),
            original_title=serial_original_name or serial_title,
            limit=50,
        )
    except Exception as exc:
        xbmc.log('Kino Stream Up Next search failed S%02dE%02d: %s' % (int(season), int(episode), exc), xbmc.LOGWARNING)
        return None
    if not variants:
        return None
    try:
        return sorted(variants, key=_source_sort_key)[0]
    except Exception:
        return variants[0]


def _build_upnext_episode_dict(serial_title, season, episode, ep_name='', ep_plot='', poster='', backdrop='', ident='', title=''):
    art = {}
    if poster:
        art['tvshow.poster'] = poster
        art['thumb'] = poster
        art['poster'] = poster
    if backdrop:
        art['tvshow.fanart'] = backdrop
        art['fanart'] = backdrop
    label = ep_name or ('S%02dE%02d' % (int(season), int(episode)))
    return {
        'episodeid': ident or ('%s_S%02dE%02d' % (_norm(serial_title or 'show'), int(season), int(episode))),
        'tvshowid': _norm(serial_title or 'show'),
        'title': label,
        'showtitle': serial_title or '',
        'plot': ep_plot or '',
        'season': int(season),
        'episode': int(episode),
        'playcount': 0,
        'rating': 0,
        'firstaired': '',
        'runtime': 0,
        'art': art,
        'filename': title or '',
    }


def _build_upnext_payload(serial_title, serial_original_name, season, episode, tmdb_id='', poster='', backdrop='', current_ident='', current_title=''):
    season = int(season)
    episode = int(episode)

    current_name = ''
    current_plot = ''
    next_name = ''
    next_plot = ''
    total_seasons = 0

    if tmdb_id and TMDB_KEY:
        try:
            season_data = tmdb_api.get_tv_season(TMDB_KEY, tmdb_id, season)
            for ep in (season_data.get('episodes') or []):
                ep_no = int(ep.get('episode_number') or 0)
                if ep_no == episode:
                    current_name = ep.get('name', '') or ''
                    current_plot = ep.get('overview', '') or ''
                elif ep_no == episode + 1:
                    next_name = ep.get('name', '') or ''
                    next_plot = ep.get('overview', '') or ''
            det = tmdb_api.get_tvshow_details(TMDB_KEY, tmdb_id) or {}
            total_seasons = int(det.get('seasons') or det.get('number_of_seasons') or 0)
            if not poster:
                poster = det.get('poster', '') or ''
            if not backdrop:
                backdrop = det.get('backdrop', det.get('fanart', '')) or ''
        except Exception as exc:
            xbmc.log('Kino Stream Up Next TMDB lookup failed: %s' % exc, xbmc.LOGWARNING)

    next_season = season
    next_episode = episode + 1
    next_variant = _find_best_episode_variant(serial_title, serial_original_name, next_season, next_episode)

    if not next_variant and total_seasons and season < total_seasons:
        next_season = season + 1
        next_episode = 1
        next_variant = _find_best_episode_variant(serial_title, serial_original_name, next_season, next_episode)
        if next_variant and tmdb_id and TMDB_KEY:
            try:
                season_data_next = tmdb_api.get_tv_season(TMDB_KEY, tmdb_id, next_season)
                for ep in (season_data_next.get('episodes') or []):
                    if int(ep.get('episode_number') or 0) == 1:
                        next_name = ep.get('name', '') or ''
                        next_plot = ep.get('overview', '') or ''
                        break
            except Exception:
                pass

    if not next_variant:
        return None

    play_params = {
        'mode': 'play',
        'ident': next_variant.get('ident', ''),
        'title': next_variant.get('name', next_name or ('S%02dE%02d' % (next_season, next_episode))),
        'size': next_variant.get('size_str', ''),
        'img': poster or '',
        'media_type': 'tvshow',
        'serial_title': serial_title or '',
        'serial_original_name': serial_original_name or serial_title or '',
        'season': str(next_season),
        'episode': str(next_episode),
        'tmdb_id': str(tmdb_id or ''),
        'poster': poster or '',
        'backdrop': backdrop or '',
    }

    return {
        'play_info': {
            'play_path': _url(**play_params),
        },
        'notification_time': 30,
        'current_episode': _build_upnext_episode_dict(
            serial_title, season, episode, current_name, current_plot,
            poster=poster, backdrop=backdrop, ident=current_ident, title=current_title
        ),
        'next_episode': _build_upnext_episode_dict(
            serial_title, next_season, next_episode, next_name, next_plot,
            poster=poster, backdrop=backdrop,
            ident=next_variant.get('ident', ''),
            title=next_variant.get('name', next_name or ('S%02dE%02d' % (next_season, next_episode)))
        )
    }


def _send_upnext_payload(payload):
    if not payload:
        return False
    return _jsonrpc_notify_all('plugin.video.kinostream.SIGNAL', 'upnext_data', payload)


def _add_dir(label, url, folder=True, img='', info=None, is_playable=False):
    li = xbmcgui.ListItem(label)
    if img:
        li.setArt({'thumb': img, 'poster': img, 'icon': img, 'fanart': img})
    if info:
        _set_info(li, info, is_folder=folder)
    if is_playable:
        li.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(addon_handle, url, li, folder)


def _end(update_listing=False):
    xbmcplugin.endOfDirectory(addon_handle, updateListing=update_listing)


def _fail(msg=''):
    if msg:
        _notify(msg, xbmcgui.NOTIFICATION_WARNING)
    xbmcplugin.endOfDirectory(addon_handle, succeeded=False)


# ══════════════════════════════════════════════════════════════════════════════
#  TOKEN / LOGIN
# ══════════════════════════════════════════════════════════════════════════════

def _load_token():
    try:
        if os.path.exists(TOKEN_FILE):
            return json.load(open(TOKEN_FILE, 'r')).get('token')
    except: pass
    return None


def _save_token(token):
    try:
        json.dump({'token': token}, open(TOKEN_FILE, 'w'))
    except: pass


def _get_token(force=False):
    if not force:
        t = _load_token()
        if t: return t
    username = addon.getSetting('username')
    password = addon.getSetting('password')
    if not username or not password:
        xbmcgui.Dialog().ok('Kino Stream',
                            'Zadejte Webshare.cz prihlasovaci udaje v Nastaveni.')
        addon.openSettings()
        username = addon.getSetting('username')
        password = addon.getSetting('password')
    if not username or not password:
        return None
    token = webshare.login(username, password)
    if token:
        _save_token(token)
    else:
        xbmcgui.Dialog().ok('Kino Stream',
                            'Prihlaseni k Webshare.cz selhalo.\nZkontrolujte jmeno a heslo.')
    return token


# ══════════════════════════════════════════════════════════════════════════════
#  WATCHED
# ══════════════════════════════════════════════════════════════════════════════

def _load_watched():
    try:
        if os.path.exists(WATCHED_FILE):
            return json.load(open(WATCHED_FILE, 'r'))
    except: pass
    return {}


def _save_watched(data):
    try:
        json.dump(data, open(WATCHED_FILE, 'w'), indent=2)
    except: pass


def _trim_watched(watched):
    max_w = int(addon.getSetting('max_watched') or '50')
    if len(watched) > max_w:
        for k, _ in sorted(watched.items(), key=lambda i: i[1]['time'], reverse=True)[max_w:]:
            del watched[k]
    return watched


def _load_recent_played():
    try:
        if os.path.exists(RECENT_FILE):
            return json.load(open(RECENT_FILE, 'r'))
    except:
        pass
    return {}


def _save_recent_played(data):
    try:
        json.dump(data, open(RECENT_FILE, 'w'), indent=2)
    except:
        pass


def _trim_recent_played(items):
    max_r = int(addon.getSetting('max_recent_played') or '50')
    if len(items) > max_r:
        for k, _ in sorted(items.items(), key=lambda i: i[1].get('time', 0), reverse=True)[max_r:]:
            del items[k]
    return items


def _load_favorites():
    try:
        if os.path.exists(FAVORITES_FILE):
            return json.load(open(FAVORITES_FILE, 'r'))
    except:
        pass
    return {}


def _save_favorites(data):
    try:
        json.dump(data, open(FAVORITES_FILE, 'w'), indent=2)
    except:
        pass


def _favorite_key(media_type, tmdb_id='', title=''):
    media_type = media_type or 'movie'
    if tmdb_id:
        return '%s:%s' % (media_type, tmdb_id)
    return '%s:title:%s' % (media_type, _norm(title or ''))


def _favorite_exists(media_type, tmdb_id='', title=''):
    return _favorite_key(media_type, tmdb_id, title) in _load_favorites()




def _kodi_version():
    try:
        return xbmc.getInfoLabel('System.BuildVersion') or 'neznamá'
    except:
        return 'neznamá'


def _platform_name():
    try:
        if xbmc.getCondVisibility('System.Platform.Windows'):
            return 'Windows'
        if xbmc.getCondVisibility('System.Platform.Linux.RaspberryPi'):
            return 'Raspberry Pi'
        if xbmc.getCondVisibility('System.Platform.Android'):
            return 'Android'
        if xbmc.getCondVisibility('System.Platform.Linux'):
            return 'Linux'
        if xbmc.getCondVisibility('System.Platform.OSX'):
            return 'macOS'
        if xbmc.getCondVisibility('System.Platform.IOS'):
            return 'iOS/tvOS'
    except:
        pass
    return sys.platform


def send_feedback():
    cats = ['Chyba', 'Nápad', 'Jiný problém']
    idx = xbmcgui.Dialog().select('Zpětná vazba', cats)
    if idx < 0:
        return _fail()
    category = cats[idx]
    message = xbmcgui.Dialog().input('Napište zprávu', type=xbmcgui.INPUT_ALPHANUM)
    if not message or not message.strip():
        _notify('Zpráva nebyla odeslána')
        return _fail()
    data = {
        'addon_version': addon.getAddonInfo('version'),
        'kodi_version': _kodi_version(),
        'platform': _platform_name(),
        'device': xbmc.getInfoLabel('System.FriendlyName') or xbmc.getInfoLabel('System.HostName') or 'neznamé',
        'category': category,
        'message': message.strip(),
    }
    try:
        body = json.dumps(data).encode('utf-8')
        req = Request(FEEDBACK_URL, data=body, headers={'Content-Type': 'application/json; charset=utf-8'})
        resp = urlopen(req, timeout=15)
        raw = resp.read()
        try:
            payload = json.loads(raw.decode('utf-8')) if raw else {'ok': True}
        except:
            payload = {'ok': True}
        if payload.get('ok'):
            xbmcgui.Dialog().ok('Kino Stream', 'Zpráva byla odeslána.')
        else:
            xbmcgui.Dialog().ok('Kino Stream', 'Odeslání selhalo.\n%s' % payload.get('error', 'Neznámá chyba'))
    except Exception as e:
        xbmcgui.Dialog().ok('Kino Stream', 'Odeslání selhalo.\n%s' % str(e))
    return _fail()


# ══════════════════════════════════════════════════════════════════════════════
#  ROOT MENU — identicky s provider.py root()
# ══════════════════════════════════════════════════════════════════════════════

def main_menu():
    xbmcplugin.setContent(addon_handle, 'videos')
    use_tmdb = addon.getSetting('use_tmdb') != 'false'

    # Stav uctu — identicky s show_account_status()
    _show_account_status()

    recent = _load_recent_played()
    if recent:
        _add_dir('[B]Naposledy prehrane[/B]', _url(mode='recent_root'),
                 img='DefaultRecentlyAddedMovies.png')

    _add_dir('[B]Muj seznam[/B]', _url(mode='favorites_root'),
             img='DefaultFavourites.png')

    # Vyhledavani — identicky s add_search_dir()
    _add_dir('[B]Hledat[/B]', _url(mode='search'), img='DefaultAddonsSearch.png')

    # Filmy
    _add_dir('[B]Filmy[/B]', _url(mode='media_root', media_type='movie'),
             img='DefaultMovies.png')

    # Serialy
    _add_dir('[B]Serialy[/B]', _url(mode='media_root', media_type='tvshow'),
             img='DefaultTVShows.png')

    # Trendy + Popularni — jen pokud TMDB
    if use_tmdb:
        _add_dir('[B]Trendy filmy[/B]', _url(mode='trending_movies'),
                 img='DefaultRecentlyAddedMovies.png')
        _add_dir('[B]Popularni filmy[/B]', _url(mode='popular_movies'),
                 img='DefaultRecentlyAddedMovies.png')

    _add_dir('[B]Stazene soubory[/B]', _url(mode='downloads'),
             img='DefaultFolder.png')

    _add_dir('[B]Zpetna vazba[/B]', _url(mode='send_feedback'), img='DefaultAddonService.png')

    _end()


def _show_account_status():
    """Zobrazí stav účtu v hlavním menu — s VIP dobou platnosti."""
    token = _load_token()
    if token:
        try:
            xml = webshare._post('user_data', {}, token=token)
            if xml and webshare._x(xml, 'status') == 'OK':
                username = webshare._x(xml, 'username') or addon.getSetting('username') or '?'
                vip      = webshare._x(xml, 'vip') == '1'
                vip_days = webshare._x(xml, 'vip_days')

                if vip and vip_days and str(vip_days).isdigit():
                    # "Uzivatel [VIP | 247 dní]"
                    badge = ' [COLOR lime][VIP | %s dní][/COLOR]' % vip_days
                elif vip:
                    badge = ' [COLOR lime][VIP][/COLOR]'
                else:
                    badge = ' [COLOR gray][Free][/COLOR]'

                _add_dir('[B]Ucet: %s%s[/B]' % (username, badge),
                         _url(mode='account_info'), img='DefaultAddonService.png')
                return
        except: pass
    _add_dir('Prihlasit se na Webshare.cz', _url(mode='do_login'),
             img='DefaultAddonService.png')


# ══════════════════════════════════════════════════════════════════════════════
#  UCET
# ══════════════════════════════════════════════════════════════════════════════

def show_account_info():
    """Identicky s provider.py show_account_info()."""
    token = _load_token()
    if not token:
        xbmcgui.Dialog().ok('Kino Stream', 'Nejste prihlaseni.')
        return _fail()
    try:
        xml = webshare._post('user_data', {}, token=token)
        if xml and webshare._x(xml, 'status') == 'OK':
            username = webshare._x(xml, 'username')
            email    = webshare._x(xml, 'email')
            vip      = webshare._x(xml, 'vip') == '1'
            vip_days = webshare._x(xml, 'vip_days')
            vip_text = ('ANO (%s dni)' % vip_days) if (vip and vip_days) else ('ANO' if vip else 'NE (viz webshare.cz)')
            xbmcgui.Dialog().ok('Webshare ucet',
                'Uzivatel: %s\nE-mail: %s\nVIP: %s' % (username, email, vip_text))
    except Exception as e:
        xbmcgui.Dialog().ok('Kino Stream', 'Nelze nacist data uctu:\n%s' % str(e))
    _fail()


def do_login():
    """Identicky s provider.py do_manual_login()."""
    username = addon.getSetting('username')
    password = addon.getSetting('password')
    if not username or not password:
        xbmcgui.Dialog().ok('Kino Stream', 'Zadejte udaje v Nastaveni doplnku.')
        addon.openSettings()
        return _fail()
    token = webshare.login(username, password)
    if token:
        _save_token(token)
        try:
            xml  = webshare._post('user_data', {}, token=token)
            uname = webshare._x(xml, 'username') if xml else username
            vip   = webshare._x(xml, 'vip') == '1' if xml else False
            badge = ' (VIP)' if vip else ' (Free)'
            xbmcgui.Dialog().ok('Kino Stream', 'Prihlasen: %s%s' % (uname, badge))
        except:
            _notify('Prihlaseni uspesne!')
    else:
        xbmcgui.Dialog().ok('Kino Stream',
                            'Prihlaseni selhalo.\nZkontrolujte jmeno a heslo.')
    _fail()


# ══════════════════════════════════════════════════════════════════════════════
#  MEDIA ROOT — podmenu Filmů / Seriálů
#  Identicky s provider.py root(media_type='movie'/'tvshow')
# ══════════════════════════════════════════════════════════════════════════════

def media_root(media_type):
    xbmcplugin.setContent(addon_handle, 'videos')
    use_tmdb = addon.getSetting('use_tmdb') != 'false'

    watched = _load_watched()
    if any(v.get('media_type') == media_type for v in watched.values()):
        _add_dir('Sledovane',
                 _url(mode='watched_list', media_type=media_type),
                 img='DefaultVideoPlaylists.png')

    # Vyhledavani
    _add_dir('[B]Hledat[/B]', _url(mode='search', search_id=media_type),
             img='DefaultAddonsSearch.png')

    # Podle abecedy
    _add_dir('Podle abecedy', _url(mode='alphabet_root', media_type=media_type),
             img='DefaultMusicAlbums.png')

    if use_tmdb:
        _add_dir('Podle zanru', _url(mode='genre_list', media_type=media_type),
                 img='DefaultGenre.png')
        _add_dir('Podle statu', _url(mode='country_list', media_type=media_type),
                 img='DefaultCountry.png')

    _end()


# ══════════════════════════════════════════════════════════════════════════════
#  ZANRY — identicky s provider.py show_genre_list() / show_genre_movies()
# ══════════════════════════════════════════════════════════════════════════════

def show_genre_list(media_type='movie'):
    xbmcplugin.setContent(addon_handle, 'videos')
    genres = tmdb_api.get_genres(TMDB_KEY, media_type=media_type)
    # get_genres vraci [(id, name), ...] — seradime abecedne podle name
    for gid, gname in sorted(genres, key=lambda g: g[1]):
        _add_dir('[B]%s[/B]' % gname,
                 _url(mode='genre_movies', genre_id=gid, genre_name=gname,
                      media_type=media_type))
    _end()


def show_genre_movies(genre_id, genre_name, media_type='movie', page=1):
    xbmcplugin.setContent(addon_handle, 'movies' if media_type == 'movie' else 'tvshows')
    page = int(page)
    try:
        if media_type == 'movie':
            results, total_pages = tmdb_api.discover_movies(
                TMDB_KEY, genre_id=genre_id, page=page)
        else:
            results, total_pages = tmdb_api.discover_tvshows(
                TMDB_KEY, genre_id=genre_id, page=page)
    except Exception as e:
        xbmc.log('SCC genre_movies: %s' % e, xbmc.LOGERROR)
        results, total_pages = [], 1

    for item in results:
        _add_tmdb_item(item, media_type)

    if page < total_pages:
        _add_dir('[B]>> Dalsi strana (%d/%d)[/B]' % (page + 1, total_pages),
                 _url(mode='genre_movies', genre_id=genre_id, genre_name=genre_name,
                      media_type=media_type, page=page + 1))
    _end()


# ══════════════════════════════════════════════════════════════════════════════
#  STATY — identicky s provider.py show_country_list() / show_country_movies()
# ══════════════════════════════════════════════════════════════════════════════

def show_country_list(media_type='movie'):
    xbmcplugin.setContent(addon_handle, 'videos')
    countries = FEATURED_COUNTRIES_MOVIE if media_type == 'movie' else FEATURED_COUNTRIES_TVSHOW
    for code in sorted(countries, key=lambda c: COUNTRY_NAMES.get(c, c)):
        name = COUNTRY_NAMES.get(code, code)
        _add_dir('[B]%s[/B]' % name,
                 _url(mode='country_movies', country_code=code,
                      country_name=name, media_type=media_type))
    _end()


def show_country_movies(country_code, country_name, media_type='movie', page=1):
    xbmcplugin.setContent(addon_handle, 'movies' if media_type == 'movie' else 'tvshows')
    page = int(page)
    try:
        if media_type == 'movie':
            results, total_pages = tmdb_api.discover_movies(
                TMDB_KEY, page=page, country_code=country_code)
        else:
            results, total_pages = tmdb_api.discover_tvshows(
                TMDB_KEY, page=page, country_code=country_code)
    except Exception as e:
        xbmc.log('SCC country_movies: %s' % e, xbmc.LOGERROR)
        results, total_pages = [], 1

    for item in results:
        _add_tmdb_item(item, media_type)

    if page < total_pages:
        _add_dir('[B]>> Dalsi strana (%d/%d)[/B]' % (page + 1, total_pages),
                 _url(mode='country_movies', country_code=country_code,
                      country_name=country_name, media_type=media_type, page=page + 1))
    _end()


# ══════════════════════════════════════════════════════════════════════════════
#  TRENDING / POPULAR — identicky s provider.py
# ══════════════════════════════════════════════════════════════════════════════

def show_trending_movies(page=1):
    xbmcplugin.setContent(addon_handle, 'movies')
    try:
        results = tmdb_api.get_trending(TMDB_KEY, media_type='movie')
    except: results = []
    for item in results:
        _add_tmdb_item(item, 'movie')
    _end()


def show_popular_movies(page=1):
    xbmcplugin.setContent(addon_handle, 'movies')
    page = int(page)
    try:
        result = tmdb_api.get_popular_movies(TMDB_KEY, page=page)
        results, total = (result if isinstance(result, tuple) else (result, 1))
    except: results, total = [], 1
    for item in results:
        _add_tmdb_item(item, 'movie')
    if page < total:
        _add_dir('[B]>> Dalsi strana[/B]', _url(mode='popular_movies', page=page + 1))
    _end()


# ══════════════════════════════════════════════════════════════════════════════
#  ZOBRAZENI TMDB POLOZKY — identicky s _show_tmdb_movie_item / _show_tmdb_tvshow_item
# ══════════════════════════════════════════════════════════════════════════════

def _add_tmdb_item(item, media_type):
    """
    Prida film nebo serial do listingu.
    Odpovida provider.py _show_tmdb_movie_item / _show_tmdb_tvshow_item.
    """
    title    = item.get('title', '')
    year     = item.get('year', '')
    plot     = item.get('plot', '')
    poster   = item.get('poster', '')
    backdrop = item.get('backdrop', '')
    tmdb_id  = item.get('tmdb_id', item.get('id', ''))
    orig     = item.get('orig_title', title)
    genres   = item.get('genres', [])

    year_str = ' (%s)' % year if year else ''
    label    = '%s%s' % (title, year_str)

    li = xbmcgui.ListItem(label)
    li.setArt({'thumb': poster, 'poster': poster,
               'fanart': backdrop or poster, 'icon': poster})
    info = {
        'title':     title,
        'plot':      plot,
        'year':      int(year) if year and str(year).isdigit() else 0,
        'genre':     ', '.join(genres) if genres else '',
        'mediatype': 'movie' if media_type == 'movie' else 'tvshow',
    }
    _set_info(li, info)

    if media_type == 'movie':
        url = _url(mode='select_quality', title=title, year=year,
                   orig_title=orig, tmdb_id=tmdb_id)
    else:
        url = _url(mode='series_list', serial_title=title, serial_year=year,
                   serial_original_name=orig, tmdb_id=tmdb_id)

    favorite_params = dict(media_type=media_type, tmdb_id=tmdb_id, title=title, year=year,
                           orig_title=orig, plot=plot, poster=poster, backdrop=backdrop,
                           genres=' / '.join(genres) if genres else '')
    if _favorite_exists(media_type, tmdb_id, title):
        ctx_items = [
            ('Odebrat z Mého seznamu', 'RunPlugin(%s)' % _url(mode='favorite_remove', **favorite_params)),
        ]
    else:
        ctx_items = [
            ('Pridat do Mého seznamu', 'RunPlugin(%s)' % _url(mode='favorite_add', **favorite_params)),
        ]
    li.addContextMenuItems(ctx_items, replaceItems=True)

    xbmcplugin.addDirectoryItem(addon_handle, url, li, True)


# ══════════════════════════════════════════════════════════════════════════════
#  VYHLEDAVANI — identicky s provider.py search()
# ══════════════════════════════════════════════════════════════════════════════

def do_search(search_id=''):
    if not search_id:
        choice = xbmcgui.Dialog().select('Co chcete hledat?', [
            'Vse',
            'Filmy',
            'Serialy',
        ])
        if choice < 0:
            return _fail()
        search_id = {0: 'all', 1: 'movie', 2: 'tvshow'}.get(choice, 'all')

    prompt = 'Hledat serial' if search_id == 'tvshow' else ('Hledat vse' if search_id == 'all' else 'Hledat film')
    kb = xbmc.Keyboard('', prompt)
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        return _fail()
    execute_search(kb.getText().strip(), search_id=search_id, page=1)


def execute_search(keyword, search_id='movie', page=1):
    use_tmdb = addon.getSetting('use_tmdb') != 'false'

    if search_id == 'all':
        return show_search_scope_menu(keyword)
    if search_id == 'files':
        return _do_search_files(keyword, media_type='movie')

    if search_id == 'tvshow':
        if use_tmdb:
            return _search_series_with_tmdb(keyword)
        return show_series_list(serial_title=keyword)

    if use_tmdb:
        return _search_movies_with_tmdb(keyword, page=page)
    return _do_search_files(keyword, media_type='movie')


def show_search_scope_menu(keyword):
    xbmcplugin.setContent(addon_handle, 'videos')
    use_tmdb = addon.getSetting('use_tmdb') != 'false'

    if not use_tmdb:
        _add_dir('[B]Filmy[/B]', _url(mode='search_run', keyword=keyword, search_id='movie'),
                 img='DefaultMovies.png')
        _add_dir('[B]Serialy[/B]', _url(mode='search_run', keyword=keyword, search_id='tvshow'),
                 img='DefaultTVShows.png')
        _end()
        return

    movies = _get_movie_search_results(keyword, page=1)
    series = _get_tv_search_results(keyword)

    if movies and not series:
        return _search_movies_with_tmdb(keyword, page=1)
    if series and not movies:
        return _search_series_with_tmdb(keyword)

    _add_dir('[B]Filmy[/B]  [I](%d)[/I]' % len(movies[:20]),
             _url(mode='search_run', keyword=keyword, search_id='movie'),
             img='DefaultMovies.png')
    _add_dir('[B]Serialy[/B]  [I](%d)[/I]' % len(series[:20]),
             _url(mode='search_run', keyword=keyword, search_id='tvshow'),
             img='DefaultTVShows.png')
    _add_dir('Hledat primo ve Webshare',
             _url(mode='search_run', keyword=keyword, search_id='files'),
             img='DefaultFolder.png')
    _end()


def _get_movie_search_results(keyword, page=1):
    clean_keyword, year = _split_search_keyword(keyword)
    query = clean_keyword or keyword
    try:
        raw = tmdb_api.search_movies(TMDB_KEY, query, year=year, page=page)
        results, _total_pages = (raw if isinstance(raw, tuple) else (raw, 1))
    except TypeError:
        raw = tmdb_api.search_movies(TMDB_KEY, query, year=year)
        results, _total_pages = (raw if isinstance(raw, tuple) else (raw, 1))
    except Exception as e:
        xbmc.log('SCC search_movies: %s' % e, xbmc.LOGERROR)
        results = []
    return _rank_tmdb_results(results, query, year=year)


def _get_tv_search_results(keyword):
    clean_keyword, year = _split_search_keyword(keyword)
    query = clean_keyword or keyword
    try:
        raw = tmdb_api.search_tvshows(TMDB_KEY, query)
        results = (raw[0] if isinstance(raw, tuple) else raw)
    except Exception as e:
        xbmc.log('SCC search_tvshows: %s' % e, xbmc.LOGERROR)
        results = []
    return _rank_tmdb_results(results, query, year=year)


def _search_movies_with_tmdb(keyword, page=1):
    """Vylepsene vyhledavani filmu: extrakce roku + lokalni rerank presnych shod."""
    xbmcplugin.setContent(addon_handle, 'movies')
    page = int(page)
    clean_keyword, year = _split_search_keyword(keyword)
    query = clean_keyword or keyword

    try:
        raw = tmdb_api.search_movies(TMDB_KEY, query, year=year, page=page)
        results, total_pages = (raw if isinstance(raw, tuple) else (raw, 1))
    except TypeError:
        raw = tmdb_api.search_movies(TMDB_KEY, query, year=year)
        results, total_pages = (raw if isinstance(raw, tuple) else (raw, 1))
    except Exception as e:
        xbmc.log('SCC search_movies: %s' % e, xbmc.LOGERROR)
        results, total_pages = [], 1

    results = _rank_tmdb_results(results, query, year=year)

    if not results:
        _do_search_files(keyword, media_type='movie')
        return

    for item in results:
        _add_tmdb_item(item, 'movie')

    if page < total_pages:
        _add_dir('[B]>> Dalsi strana[/B]',
                 _url(mode='search_more', keyword=keyword, search_id='movie', page=page + 1))
    _end()


def _search_series_with_tmdb(keyword):
    """Vylepsene vyhledavani serialu: cisti dotaz a preferuje presne shody."""
    xbmcplugin.setContent(addon_handle, 'tvshows')
    results = _get_tv_search_results(keyword)

    if not results:
        show_series_list(serial_title=_split_search_keyword(keyword)[0] or keyword)
        return

    for item in results:
        _add_tmdb_item(item, 'tvshow')
    _end()


def search_more(keyword, search_id='movie', page=1):
    execute_search(keyword, search_id=search_id, page=int(page))


# ══════════════════════════════════════════════════════════════════════════════
#  WEBSHARE SOUBORY — identicky s _do_search_files / _show_file_items / _add_video_item
# ══════════════════════════════════════════════════════════════════════════════

def _do_search_files(query, media_type='movie'):
    """Priamy fallback do Webshare se smart parsovanim roku a cistejsim dotazem."""
    token = _get_token()
    if not token: return _fail()

    clean_query, year = _split_search_keyword(query)
    ws_query = clean_query or query

    prog = xbmcgui.DialogProgress()
    prog.create('Kino Stream', 'Hledani: %s' % query)
    try:
        files = webshare.search_for_title(token, ws_query, year=year)
        if not files and ws_query != query:
            files = webshare.search_for_title(token, query)
    except:
        files = []
    finally:
        prog.close()

    if not files:
        return _fail('Zadne vysledky pro: %s' % query)

    xbmcplugin.setContent(addon_handle, 'movies' if media_type == 'movie' else 'tvshows')
    _show_file_items(files, media_type=media_type)
    _end()


def _show_file_items(files, media_type='movie', poster='', backdrop='', force_variants=False):
    """
    Identicky s provider.py _show_file_items().
    Grupuje soubory podle nazvu (bez quality tagů).
    """
    grouped = {}
    for f in files:
        base = re.sub(QUALITY_PATTERN, '', f['name'], flags=re.I)
        base = re.sub(r'[._]', ' ', base)
        base = re.sub(r'\s+', ' ', base).strip()
        grouped.setdefault(base, []).append(f)

    for base_title, variants in sorted(grouped.items()):
        if len(variants) == 1:
            _add_video_item(variants[0], media_type, show_quality=False,
                            poster=poster, backdrop=backdrop)
        else:
            # Identicky s provider.py: slozka s variantami
            li = xbmcgui.ListItem(
                '[B]%s[/B]  [I](%d verzi)[/I]' % (base_title, len(variants)))
            if poster:
                li.setArt({'thumb': poster, 'poster': poster, 'fanart': backdrop or poster})
            xbmcplugin.addDirectoryItem(addon_handle,
                _url(mode='quality_select',
                     variants=json.dumps([{
                         'name': v['name'], 'ident': v['ident'],
                         'size': v.get('size_str', ''), 'size_b': str(v.get('size', 0)),
                         'positive': str(v.get('positive', 0)),
                         'negative': str(v.get('negative', 0)),
                         'desc': v.get('desc', ''),
                     } for v in variants]),
                     media_type=media_type, poster=poster, backdrop=backdrop),
                li, True)




def _show_movie_sources_dialog(variants, title='', plot='', poster='', backdrop='', tmdb_id='', year='', orig_title=''):
    items = []
    exists = _favorite_exists('movie', tmdb_id, title)
    items.append({
        'action': 'favorite_remove' if exists else 'favorite_add',
        'label': ('Odebrat z Mého seznamu' if exists else 'Přidat do Mého seznamu'),
        'icon': ''
    })
    probe_map = _enrich_variants_with_probe(variants)
    for v in sorted(variants, key=_source_sort_key):
        label, badge = _build_source_label(v.get('name', ''), v.get('size_b', 0), v.get('size', ''), probe_map.get(v.get('ident', '')))
        badge_icon = _source_badge_icon(badge) if badge else ''
        items.append({
            'action': 'play',
            'label': label,
            'icon': badge_icon if os.path.exists(badge_icon) else '',
            'variant': v
        })

    dlg = SourceSelectDialog('DialogSourceSelect.xml', ADDON_DIR, 'Default', '1080i',
                             items_data=items, poster=poster or backdrop,
                             plot='')
    dlg.doModal()
    selected = dlg.selected
    del dlg
    if not selected:
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        return

    if selected.get('action') in ('favorite_add', 'favorite_remove'):
        if selected['action'] == 'favorite_add':
            favorite_add(media_type='movie', tmdb_id=tmdb_id, title=title, year=year,
                         orig_title=orig_title or title, plot=plot, poster=poster, backdrop=backdrop)
        else:
            favorite_remove(media_type='movie', tmdb_id=tmdb_id, title=title)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        return

    v = selected.get('variant') or {}
    if selected.get('action') == 'download':
        download_webshare_file(v.get('ident', ''), title=v.get('name', title), size=v.get('size', ''), img=poster, media_type='movie')
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        return
    play_file_direct(v.get('ident', ''), title=v.get('name', title), size=v.get('size', ''), img=poster, media_type='movie')


def show_quality_select(variants_json, media_type='movie', poster='', backdrop=''):
    """Identicky s provider.py _show_quality_select() — serazeno podle velikosti."""
    xbmcplugin.setContent(addon_handle, 'videos')
    try:
        variants = json.loads(variants_json)
    except: variants = []
    # Seradit podle velikosti sestupne (jako parse_size_mb v provider.py)
    def _mb(v):
        try: return int(v.get('size_b', 0))
        except: return 0
    for v in sorted(variants, key=_source_sort_key):
        _add_video_item(v, media_type, show_quality=True, poster=poster, backdrop=backdrop)
    _end()


def _add_video_item(f, media_type, show_quality=False, poster='', backdrop=''):
    """Identicky s provider.py _add_video_item()."""
    name  = f.get('name', f.get('title', ''))
    ident = f.get('ident', '')
    size  = f.get('size_str', f.get('size', ''))
    plus  = f.get('positive', 0)
    minus = f.get('negative', 0)
    desc  = f.get('desc', '')

    if show_quality:
        label, badge = _build_source_label(name, f.get('size', 0), size, None)
    else:
        label = re.sub(r'\s+', ' ', re.sub(QUALITY_PATTERN, '', name, flags=re.I)).strip()
        badge = ''
        if size:
            label += '  [I][%s][/I]' % size
        if plus or minus:
            label += '  [I]+%s -%s[/I]' % (plus, minus)

    li = xbmcgui.ListItem(label)
    li.setProperty('IsPlayable', 'true')
    art = {}
    if poster:
        art.update({'thumb': poster, 'poster': poster, 'fanart': backdrop or poster})
    if show_quality and badge:
        badge_icon = _source_badge_icon(badge)
        if os.path.exists(badge_icon):
            art.update({'icon': badge_icon, 'thumb': badge_icon})
    if art:
        li.setArt(art)
    plot = ('%s\n\n' % desc if desc else '') + 'Velikost: %s  |  +%s -%s' % (size, plus, minus)
    _set_info(li, {'title': name, 'plot': plot,
                   'mediatype': 'movie' if media_type == 'movie' else 'episode'})

    li.addContextMenuItems([
        ('Pridat do Sledovanych',
         'RunPlugin(%s)' % _url(mode='add_watched', ident=ident,
                                title=name, size=size, img=poster, media_type=media_type)),
        ('Stahnout',
         'RunPlugin(%s)' % _url(mode='download_ws', ident=ident,
                                title=name, size=size, img=poster, media_type=media_type))
    ])

    xbmcplugin.addDirectoryItem(addon_handle,
        _url(mode='play', ident=ident, title=name, size=size, img=poster,
             media_type=media_type), li, False)


# ══════════════════════════════════════════════════════════════════════════════
#  SELECT QUALITY (film z TMDB → WS search)
#  Identicky s workflow _show_tmdb_movie_item v provider.py
# ══════════════════════════════════════════════════════════════════════════════

def select_quality(title, year='', orig_title='', tmdb_id=''):
    token = _get_token()
    if not token: return _fail()

    files = _get_cached_movie_files(title, year=year, orig_title=orig_title)
    if not files:
        prog = xbmcgui.DialogProgress()
        prog.create('Kino Stream', 'Hledani: %s' % title)
        try:
            files = webshare.search_for_title(token, title, year=year,
                                              original_title=orig_title, limit=30)
        except:
            files = []
        finally:
            prog.close()

        # Fallback — znovu po re-loginu
        if not files:
            token = _get_token(force=True)
            if token:
                try:
                    files = webshare.search_for_title(token, title, year=year,
                                                      original_title=orig_title, limit=30)
                except:
                    files = []

    # Kdyz nic nenajde pres primy title search, zkus jeste volnejsi fallback pres TMDB/alt query.
    if not files:
        fallback_queries = []
        for q in [orig_title, title]:
            q = (q or '').strip()
            if q and q not in fallback_queries:
                fallback_queries.append(q)
        # posledni slovo z nazvu byva casto na Webshare lepe pojmenovane pod originálem
        for q in list(fallback_queries):
            words = _clean_title_tokens(q)
            if len(words) >= 2:
                alt = ' '.join(words[:4])
                if alt and alt not in fallback_queries:
                    fallback_queries.append(alt)
        for q in fallback_queries:
            try:
                broad = webshare._raw_search(token, q, limit=80)
            except Exception:
                broad = []
            if not broad:
                continue
            broad = _filter_movie_files_precise(broad, title, year=year, orig_title=orig_title)
            if broad:
                files = broad
                xbmc.log('Kino Stream fallback movie search: %d výsledků pro "%s"' % (len(files), q), xbmc.LOGINFO)
                break

    # Nacist poster z TMDB
    poster, backdrop = '', ''
    if tmdb_id and TMDB_KEY:
        try:
            det = tmdb_api.get_movie_details(TMDB_KEY, tmdb_id)
            poster   = det.get('poster', '')
            backdrop = det.get('backdrop', '')
        except: pass

    xbmcplugin.setContent(addon_handle, 'movies')

    raw_candidates = list(files or [])
    files = _filter_movie_files_precise(files, title, year=year, orig_title=orig_title)
    if not files:
        # posledni fallback: nech nejpravděpodobnější názvy místo tvrdého selhání
        candidates = raw_candidates or _get_cached_movie_files(title, year=year, orig_title=orig_title) or []
        wanted_titles = [x for x in [title, orig_title] if x]
        relaxed = []
        for f in candidates:
            name = f.get('name', '')
            info = webshare.parse_filename(name)
            if info.get('season') is not None or info.get('episode') is not None:
                continue
            score = _relaxed_title_overlap(name, wanted_titles)
            if score >= 0.45:
                f = dict(f)
                f['_relaxed_score'] = score
                relaxed.append(f)
        relaxed.sort(key=lambda x: (-x.get('_relaxed_score', 0), -int(x.get('size', 0) or 0)))
        if relaxed:
            files = relaxed[:20]
            xbmc.log('Kino Stream relaxed movie fallback: %d výsledků pro %s' % (len(files), title), xbmc.LOGWARNING)
    _set_cached_movie_files(title, year=year, orig_title=orig_title, files=files)

    plot = ''
    if tmdb_id and TMDB_KEY:
        try:
            det = tmdb_api.get_movie_details(TMDB_KEY, tmdb_id)
            plot = det.get('plot', '') or det.get('overview', '') or ''
            if not poster:
                poster = det.get('poster', '')
            if not backdrop:
                backdrop = det.get('backdrop', '')
        except Exception:
            pass

    variants = []
    for f in files:
        variants.append({
            'name': f.get('name', ''),
            'ident': f.get('ident', ''),
            'size': f.get('size_str', ''),
            'size_b': int(f.get('size', 0) or 0),
            'positive': int(f.get('positive', 0) or 0),
            'negative': int(f.get('negative', 0) or 0),
            'desc': f.get('desc', ''),
        })

    if not variants:
        return _fail('Nebyly nalezeny zadne odpovidajici zdroje')

    return _show_movie_sources_dialog(variants, title=title, plot=plot, poster=poster, backdrop=backdrop, tmdb_id=tmdb_id, year=year, orig_title=orig_title)

    if not files:
        li = xbmcgui.ListItem('[COLOR red]Neni k dispozici: %s[/COLOR]' % title)
        xbmcplugin.addDirectoryItem(addon_handle, '', li, False)
        return _end()

    _add_movie_list_toggle(title=title, year=year, orig_title=orig_title, tmdb_id=tmdb_id, poster=poster, backdrop=backdrop)

    # Pro filmy zobrazujeme rovnou SCC-like seznam variant misto syrovych souboru/skupin.
    variants = []
    for f in files:
        variants.append({
            'name': f.get('name', ''),
            'ident': f.get('ident', ''),
            'size': f.get('size_str', ''),
            'size_b': str(f.get('size', 0)),
            'positive': str(f.get('positive', 0)),
            'negative': str(f.get('negative', 0)),
            'desc': f.get('desc', ''),
        })
    show_quality_select(json.dumps(variants), media_type='movie', poster=poster, backdrop=backdrop)


# ══════════════════════════════════════════════════════════════════════════════
#  SERIALY — identicky s provider.py _show_series_list()
# ══════════════════════════════════════════════════════════════════════════════

def show_series_list(serial_title, serial_year='', serial_original_name='',
                     tmdb_id='', num_seasons=0):
    """
    Zobrazí seznam sérií.
    TMDB se vyhledává OBĚMA názvy (EN orig + CZ), aby se správně identifikovalo
    tmdb_id a num_seasons. WS search pak vždy dostane EN orig_title.
    """
    xbmcplugin.setContent(addon_handle, 'tvshows')
    use_tmdb    = addon.getSetting('use_tmdb') != 'false'
    num_seasons = int(num_seasons) if num_seasons else 0

    # Doplnime TMDB data pokud chybi — hledáme OBĚMA názvy
    if use_tmdb and not (tmdb_id and num_seasons):
        orig = serial_original_name or serial_title
        cz   = serial_title

        # Kandidáti pro TMDB search: nejdřív EN orig, pak CZ (pokud se liší)
        candidates = [orig]
        if cz and _norm(cz) != _norm(orig):
            candidates.append(cz)

        for query in candidates:
            try:
                results = tmdb_api.search_tvshows(TMDB_KEY, query)
                if isinstance(results, tuple):
                    results = results[0]
                if results:
                    best      = results[0]
                    tmdb_id   = best.get('tmdb_id', best.get('id', ''))
                    # Aktualizuj orig_title z TMDB (EN) pro WS search
                    tmdb_orig = best.get('orig_title', '')
                    if tmdb_orig and not serial_original_name:
                        serial_original_name = tmdb_orig
                    elif tmdb_orig:
                        serial_original_name = tmdb_orig  # vždy přepiš EN originálem
                    if tmdb_id:
                        det = tmdb_api.get_tvshow_details(TMDB_KEY, tmdb_id)
                        if det:
                            num_seasons = det.get('seasons', det.get('number_of_seasons', 0))
                            # Také aktualizuj orig z detailu
                            if det.get('orig_title'):
                                serial_original_name = det['orig_title']
                if tmdb_id and num_seasons:
                    xbmc.log('SCC series_list: TMDB found "%s" (id=%s, seasons=%d) via query "%s"' % (
                        serial_original_name, tmdb_id, num_seasons, query), xbmc.LOGINFO)
                    break
            except Exception as e:
                xbmc.log('SCC series_list TMDB error: %s' % e, xbmc.LOGERROR)

    if use_tmdb and tmdb_id and num_seasons:
        found_seasons = list(range(1, int(num_seasons) + 1))
    else:
        # Fallback — detekce pres Webshare
        token = _get_token()
        if not token: return _fail()
        found_set   = set()
        # Hledej oběma názvy
        search_queries = []
        if serial_original_name:
            search_queries.append('%s S01' % serial_original_name)
        if serial_title and _norm(serial_title) != _norm(serial_original_name or ''):
            search_queries.append('%s S01' % serial_title)

        prog = xbmcgui.DialogProgress()
        prog.create('Kino Stream', 'Detekuji serie: %s' % serial_title)
        try:
            for q in search_queries:
                try:
                    for f in webshare._raw_search(token, q, limit=50):
                        s = f.get('season')
                        if s: found_set.add(s)
                except: pass
            max_s = max(found_set) if found_set else 0
            search_base = serial_original_name or serial_title
            for s in range(1, max_s + 3):
                if s in found_set: continue
                try:
                    for f in webshare._raw_search(token, '%s S%02d' % (search_base, s), limit=20):
                        sn = f.get('season')
                        if sn: found_set.add(sn)
                except: pass
        finally:
            prog.close()
        found_seasons = sorted(found_set)

    if not found_seasons:
        return _fail('Serial nenalezen: %s' % serial_title)

    # Nacti poster
    poster = ''
    if tmdb_id and TMDB_KEY:
        try:
            det    = tmdb_api.get_tvshow_details(TMDB_KEY, tmdb_id)
            poster = det.get('poster', '') if det else ''
        except: pass

    xbmc.log('SCC series_list: %s / orig="%s" tmdb_id=%s seasons=%s' % (
        serial_title, serial_original_name, tmdb_id, found_seasons), xbmc.LOGINFO)

    _add_series_list_toggle(serial_title=serial_title, serial_year=serial_year,
                            serial_original_name=serial_original_name, tmdb_id=tmdb_id,
                            poster=poster, backdrop=poster)

    for s in found_seasons:
        li = xbmcgui.ListItem('[B]Serie %d[/B]' % s)
        if poster:
            li.setArt({'thumb': poster, 'poster': poster, 'fanart': poster})
        xbmcplugin.addDirectoryItem(addon_handle,
            _url(mode='episodes', serial_title=serial_title,
                 serial_original_name=serial_original_name,
                 serial_year=serial_year, tmdb_id=tmdb_id, season=s),
            li, True)

    _end()


# ══════════════════════════════════════════════════════════════════════════════
#  EPIZODY — identicky s provider.py _show_episodes()
# ══════════════════════════════════════════════════════════════════════════════

def show_episodes(serial_title, season, serial_year='',
                  serial_original_name='', tmdb_id=''):
    """
    Hledá epizody ve ČTYŘECH vlnách:
    1. EN originální název  (Stargate Atlantis S04)
    2. CZ název             (Hvězdná brána S04)
    3. Klíčové slovo z EN   (Atlantis S04)
    4. Klíčové slovo z CZ   (Hvezdna S04)
    Výsledky sloučí, vyfiltruje správnou sérii a seřadí do epizod.
    """
    xbmcplugin.setContent(addon_handle, 'episodes')
    season    = int(season)
    token     = _get_token()
    if not token: return _fail()

    orig_name = serial_original_name or serial_title   # EN: "Stargate Atlantis"
    cz_name   = serial_title                            # CZ: "Hvězdná brána"

    items    = []
    existing = set()

    def _merge(new_items):
        for ni in new_items:
            if ni['ident'] not in existing:
                items.append(ni)
                existing.add(ni['ident'])

    prog = xbmcgui.DialogProgress()
    prog.create('Kino Stream',
                'Nacitam serie %d: %s' % (season, cz_name or orig_name))
    try:
        # === VLNA 1: EN originální název ===
        q1 = '%s S%02d' % (orig_name, season)
        xbmc.log('SCC episodes Q1 (EN): %s' % q1, xbmc.LOGINFO)
        _merge(webshare._raw_search(token, q1, limit=50))

        # === VLNA 2: CZ název (pokud se liší od EN) ===
        if cz_name and _norm(cz_name) != _norm(orig_name):
            q2 = '%s S%02d' % (cz_name, season)
            xbmc.log('SCC episodes Q2 (CZ): %s' % q2, xbmc.LOGINFO)
            _merge(webshare._raw_search(token, q2, limit=50))

        # === VLNA 3: Klíčové slovo z EN (Atlantis S04, Stargate S04) ===
        kw_en = _extract_keyword(orig_name)
        if kw_en and len(kw_en) > 4:
            q3 = '%s S%02d' % (kw_en, season)
            if _norm(q3) not in (_norm(q1),):
                xbmc.log('SCC episodes Q3 (kw_EN): %s' % q3, xbmc.LOGINFO)
                _merge(webshare._raw_search(token, q3, limit=30))

        # === VLNA 4: Klíčové slovo z CZ (Brana S04, Hvezdna S04) ===
        kw_cz = _extract_keyword(cz_name) if cz_name else ''
        if kw_cz and len(kw_cz) > 4 and _norm(kw_cz) != _norm(kw_en):
            q4 = '%s S%02d' % (kw_cz, season)
            xbmc.log('SCC episodes Q4 (kw_CZ): %s' % q4, xbmc.LOGINFO)
            _merge(webshare._raw_search(token, q4, limit=30))

    except Exception as e:
        xbmc.log('SCC episodes error: %s' % e, xbmc.LOGERROR)
    finally:
        prog.close()

    xbmc.log('SCC episodes raw: %d files for "%s"/"%s" S%02d' % (
        len(items), cz_name, orig_name, season), xbmc.LOGINFO)

    # Filtruj pouze epizody správné série — s kontrolou názvu
    filtered = _filter_season(items, season,
                               serial_title=cz_name,
                               serial_original_name=orig_name)
    xbmc.log('SCC episodes filtered: %d/%d' % (len(filtered), len(items)), xbmc.LOGINFO)

    if not filtered:
        return _fail('Zadne epizody pro: %s S%02d' % (cz_name, season))

    # Nacti nazvy a popisy epizod z TMDB (cs-CZ)
    ep_names, ep_plots = {}, {}
    poster = ''
    backdrop = ''
    if addon.getSetting('use_tmdb') != 'false' and tmdb_id and TMDB_KEY:
        try:
            det = tmdb_api.get_tvshow_details(TMDB_KEY, tmdb_id) or {}
            poster = det.get('poster', '') or ''
            backdrop = det.get('backdrop', det.get('fanart', '')) or poster
        except Exception:
            poster = ''
            backdrop = ''
        try:
            season_data = tmdb_api.get_tv_season(TMDB_KEY, tmdb_id, season)
            for ep in (season_data.get('episodes') or []):
                n = ep.get('episode_number')
                if n is not None:
                    ep_names[n] = ep.get('name', '')
                    ep_plots[n] = ep.get('overview', '')
            xbmc.log('SCC TMDB ep names: %d entries for S%02d' % (len(ep_names), season), xbmc.LOGINFO)
        except Exception as e:
            xbmc.log('SCC TMDB season error: %s' % e, xbmc.LOGERROR)

    # Seskupit podle cisla epizody, seradit varianty podle kvality
    groups = _group_by_episode(filtered)

    for ep_num in sorted(groups.keys()):
        variants = groups[ep_num]
        ep_label = 'S%02dE%02d' % (season, ep_num)
        ep_name  = ep_names.get(ep_num, '')
        ep_plot  = ep_plots.get(ep_num, '')

        folder_title = ('[B]%s  %s[/B]' % (ep_label, ep_name)
                        if ep_name else '[B]%s[/B]' % ep_label)

        li = xbmcgui.ListItem(folder_title)
        _set_info(li, {
            'title':     '%s - %s' % (ep_label, ep_name) if ep_name else ep_label,
            'season':    season,
            'episode':   ep_num,
            'plot':      ep_plot or '',
            'mediatype': 'episode',
        })

        xbmcplugin.addDirectoryItem(addon_handle,
            _url(mode='episode_variants',
                 variants=json.dumps([{
                     'name':     v['name'],
                     'ident':    v['ident'],
                     'size':     v.get('size_str', ''),
                     'size_b':   str(v.get('size', 0)),
                     'positive': str(v.get('positive', 0)),
                     'negative': str(v.get('negative', 0)),
                     'desc':     v.get('desc', ''),
                 } for v in variants]),
                 season=season, ep_num=ep_num,
                 ep_name=ep_name, ep_plot=ep_plot,
                 serial_title=cz_name, serial_original_name=orig_name,
                 tmdb_id=tmdb_id, poster=poster, backdrop=backdrop),
            li, True)

    _end()


# ══════════════════════════════════════════════════════════════════════════════
#  VARIANTY EPIZODY — identicky s provider.py _show_episode_variants()
# ══════════════════════════════════════════════════════════════════════════════

def _show_episode_sources_dialog(variants, season, ep_num, ep_name='', ep_plot='', serial_title='', serial_original_name='', tmdb_id='', poster='', backdrop=''):
    ep_label = 'S%02dE%02d' % (int(season), int(ep_num))
    items = []
    probe_map = _enrich_variants_with_probe(variants)
    for v in sorted(variants, key=_source_sort_key):
        label, badge = _build_source_label(v.get('name', ''), v.get('size_b', 0), v.get('size', ''), probe_map.get(v.get('ident', '')))
        if not label:
            label = v.get('size', '') or v.get('name', '')
        badge_icon = _source_badge_icon(badge) if badge else ''
        items.append({
            'action': 'play',
            'label': label,
            'icon': badge_icon if badge_icon and os.path.exists(badge_icon) else '',
            'variant': v
        })
    dlg = SourceSelectDialog('DialogSourceSelect.xml', ADDON_DIR, 'Default', '1080i',
                             items_data=items, poster='',
                             plot=(ep_label + ('  ' + ep_name if ep_name else '')))
    dlg.doModal()
    selected = dlg.selected
    del dlg
    if not selected:
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        return
    v = selected.get('variant') or {}
    if selected.get('action') == 'download':
        download_webshare_file(v.get('ident', ''), title=v.get('name', ep_label), size=v.get('size', ''), img='', media_type='tvshow')
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        return
    play_file_direct(v.get('ident', ''), title=v.get('name', ep_label), size=v.get('size', ''), img=poster or '', media_type='tvshow', serial_title=serial_title, serial_original_name=serial_original_name, season=season, episode=ep_num, tmdb_id=tmdb_id, poster=poster, backdrop=backdrop)


def show_episode_variants(variants_json, season, ep_num, ep_name='', ep_plot='', serial_title='', serial_original_name='', tmdb_id='', poster='', backdrop=''):
    """Varianty epizody v custom dialogu jako u filmů."""
    try:
        variants = json.loads(variants_json)
    except Exception:
        variants = []
    if not variants:
        return _fail('Zadne zdroje pro epizodu')
    return _show_episode_sources_dialog(variants, season, ep_num, ep_name=ep_name, ep_plot=ep_plot, serial_title=serial_title, serial_original_name=serial_original_name, tmdb_id=tmdb_id, poster=poster, backdrop=backdrop)

# ══════════════════════════════════════════════════════════════════════════════
#  FILTROVANI / PARSOVANI — ekvivalent file_filter.py z provider.py
# ══════════════════════════════════════════════════════════════════════════════

def _filter_season(files, season, serial_title='', serial_original_name=''):
    """
    Filtruje soubory na danou sezónu A správný seriál.
    Dvojitá kontrola: číslo sezóny + shoda názvu seriálu.
    Zabraňuje: "Hvězdná brána S01" → soubory z Red Dwarf S01
    """
    import unicodedata

    def _norm_title(s):
        try:
            n = unicodedata.normalize('NFD', s or '')
            return re.sub(r'\s+', ' ',
                   re.sub(r'[._\-]', ' ',
                   ''.join(c for c in n if unicodedata.category(c) != 'Mn'))
                   ).lower().strip()
        except:
            return (s or '').lower().strip()

    def _title_ok(filename):
        """Zkontroluje jestli název souboru odpovídá seriálu."""
        fn = _norm_title(filename)
        # Stačí shoda s jedním z názvů (EN nebo CZ)
        for t in [serial_original_name, serial_title]:
            if not t:
                continue
            nt = _norm_title(t)
            # Celý název je obsažen
            if nt and nt in fn:
                return True
            # Všechna slova > 2 znaky jsou obsažena
            words = [w for w in nt.split() if len(w) > 2]
            if words:
                hits = sum(1 for w in words
                           if re.search(r'\b' + re.escape(w) + r'\b', fn))
                if len(words) == 1 and hits == 1:
                    return True
                if len(words) == 2 and hits == 2:
                    return True
                if len(words) > 2 and hits / float(len(words)) >= 0.85:
                    return True
        # Pokud nemáme žádný název k porovnání, přijmeme soubor
        return not (serial_title or serial_original_name)

    result = []
    for f in files:
        fs = f.get('season')   # int nebo None z parse_filename()
        fe = f.get('episode')
        name = f.get('name', '')

        # Kontrola sezóny
        season_ok = False
        if fs is not None:
            if fs == season and fe is not None:
                season_ok = True
        else:
            m = re.search(r'(?i)[Ss](\d{1,2})[Ee]\d{1,2}', name)
            if m and int(m.group(1)) == season:
                season_ok = True
            else:
                m = re.search(r'\b(\d{1,2})[xX](\d{2})\b', name)
                if m and int(m.group(1)) == season:
                    season_ok = True

        if not season_ok:
            continue

        # Kontrola názvu seriálu — zabrání průniku jiných seriálů
        if not _title_ok(name):
            xbmc.log('SCC filter: zamitnuto (jiny serial) [%s]' % name, xbmc.LOGDEBUG)
            continue

        result.append(f)

    if result:
        return result

    # Poslední fallback: nech soubory správné sezóny i bez přísné shody názvu.
    relaxed = []
    for f in files:
        fs = f.get('season')
        fe = f.get('episode')
        name = f.get('name', '')
        season_ok = False
        if fs is not None:
            if fs == season and fe is not None:
                season_ok = True
        else:
            m = re.search(r'(?i)[Ss](\d{1,2})[Ee]\d{1,2}', name)
            if m and int(m.group(1)) == season:
                season_ok = True
            else:
                m = re.search(r'(\d{1,2})[xX](\d{2})', name)
                if m and int(m.group(1)) == season:
                    season_ok = True
        if season_ok:
            relaxed.append(f)
    if relaxed:
        xbmc.log('SCC filter season relaxed fallback: %d files for season %d' % (len(relaxed), season), xbmc.LOGWARNING)
        return relaxed

    return result


def _group_by_episode(files):
    """
    Seskupi soubory podle cisla epizody.
    Podporuje: S04E06, S04E06E07 (multi), 4x06
    Seřadí varianty: nejlepší kvalita první.
    """
    groups = {}
    for f in files:
        ep = f.get('episode')  # z parse_filename() — int nebo None

        if ep is None:
            name = f.get('name', '')
            # S04E06 nebo S04E06E07
            m = re.search(r'(?i)[Ss]\d{1,2}[Ee](\d{1,2})', name)
            if m:
                ep = int(m.group(1))
            else:
                # 4x06
                m = re.search(r'\b\d{1,2}[xX](\d{2})\b', name)
                ep = int(m.group(1)) if m else 0

        groups.setdefault(int(ep), []).append(f)

    # Seradit varianty: nejlepsi kvalita první (rank ASC), pak velikost DESC
    for ep in groups:
        groups[ep].sort(key=lambda x: (x.get('quality_rank', 99), -x.get('size', 0)))
    return groups


def _extract_keyword(title):
    """
    Nejdelsi slovo z nazvu (ekvivalent _extract_keywords() z provider.py).
    Pouziva se jako fallback query pro WS search.
    """
    words = [w for w in re.split(r'\W+', title) if len(w) > 3]
    return max(words, key=len) if words else ''


def _parse_quality(name):
    """
    Vraci (label, rank) — heuristicky odhad kvality bez ffprobe.
    rank: 100=4K, 80=1080p, 60=720p, 40=SD, 20=nizka
    """
    label, qrank = webshare.infer_quality(name or '', 0)
    if label in ('4K',):
        return '4K', 100
    if label in ('1080p', '1080i', 'BluRay', 'WEB-DL', 'WEBRip'):
        return '1080p', 80
    if label in ('720p', 'HDTV'):
        return '720p', 60
    if label in ('DVDRip', '480p', 'DVDScr'):
        return 'SD', 40
    if label in ('CAM', 'TS'):
        return 'CAM', 20
    return '', 50
def _parse_language(name):
    """
    Vraci jazykovy retezec (CZ, SK, EN, CZ+SK, atd.).
    Ekvivalent parse_language() z provider.py.
    """
    n = name.upper()
    langs = []
    if re.search(r'\bCZ[\. \-_]?(DUB|DAB|DABING|TITULKY)?\b', n): langs.append('CZ')
    if re.search(r'\bSK[\. \-_]?(DUB|DAB|DABING|TITULKY)?\b', n): langs.append('SK')
    if re.search(r'\b(ENG|EN|ENGLISH)\b', n): langs.append('EN')
    return '+'.join(langs) if langs else ''


# ══════════════════════════════════════════════════════════════════════════════
#  ABECEDA
# ══════════════════════════════════════════════════════════════════════════════

def _load_alphabet_cache():
    try:
        if os.path.exists(ALPHABET_CACHE_FILE):
            with open(ALPHABET_CACHE_FILE, 'r') as fh:
                return json.load(fh)
    except:
        pass
    return {}


def _save_alphabet_cache(data):
    try:
        with open(ALPHABET_CACHE_FILE, 'w') as fh:
            json.dump(data, fh)
    except:
        pass


def _alphabet_chars():
    return list('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789')


def _title_starts_with(title, prefix):
    return _norm(title).startswith(_norm(prefix))


def _alphabet_item_matches(item, prefix):
    title = item.get('title', '')
    orig = item.get('orig_title', '')
    return _title_starts_with(title, prefix) or _title_starts_with(orig, prefix)


def _alphabet_item_sort_key(item):
    return (_norm(item.get('title', '')), _norm(item.get('orig_title', '')), str(item.get('year', '')))


def _alphabet_fetch_items(prefix, media_type='movie', max_pages=8):
    prefix = (prefix or '').strip()
    if not prefix or not TMDB_KEY:
        return []

    fetch_fn = tmdb_api.search_tvshows if media_type == 'tvshow' else tmdb_api.search_movies
    queries = []
    for q in [prefix, _norm(prefix)]:
        if q and q not in queries:
            queries.append(q)

    items = {}
    for q in queries:
        for page in range(1, max_pages + 1):
            try:
                raw = fetch_fn(TMDB_KEY, q, page=page)
                results, total_pages = (raw if isinstance(raw, tuple) else (raw, 1))
            except TypeError:
                raw = fetch_fn(TMDB_KEY, q)
                results, total_pages = (raw if isinstance(raw, tuple) else (raw, 1))
                if page > 1:
                    break
            except Exception as e:
                xbmc.log('Kino Stream alphabet TMDB [%s/%s]: %s' % (q, page, e), xbmc.LOGERROR)
                break

            for item in results or []:
                if not _alphabet_item_matches(item, prefix):
                    continue
                key = str(item.get('tmdb_id') or item.get('id') or '') + '|' + _norm(item.get('title', ''))
                items[key] = item

            if page >= int(total_pages or 1):
                break

    return sorted(items.values(), key=_alphabet_item_sort_key)


def _alphabet_get_items(prefix, media_type='movie'):
    cache = _load_alphabet_cache()
    cache_key = '%s|%s' % (media_type, (prefix or '').upper())
    items = cache.get(cache_key)
    if isinstance(items, list) and (not items or isinstance(items[0], dict)):
        return items
    items = _alphabet_fetch_items(prefix, media_type=media_type)
    cache[cache_key] = items
    _save_alphabet_cache(cache)
    return items


def _alphabet_probe_children(prefix, media_type='movie', items=None):
    items = items if items is not None else _alphabet_get_items(prefix, media_type=media_type)
    branches = {}
    pnorm = _norm(prefix)
    valid_chars = set(_alphabet_chars())

    for item in items:
        candidate = item.get('title', '') or item.get('orig_title', '')
        cand_norm = _norm(candidate)
        if not cand_norm.startswith(pnorm):
            alt_norm = _norm(item.get('orig_title', ''))
            if not alt_norm.startswith(pnorm):
                continue
            cand_norm = alt_norm

        if len(cand_norm) <= len(pnorm):
            continue

        idx = len(pnorm)
        separator = ''

        while idx < len(cand_norm) and not cand_norm[idx].isalnum():
            separator = ' '
            idx += 1

        if idx >= len(cand_norm):
            continue

        next_ch = cand_norm[idx].upper()
        if next_ch not in valid_chars:
            continue

        child = (prefix + separator + next_ch).strip()
        branches[child] = branches.get(child, 0) + 1

    return sorted(branches.items(), key=lambda x: (_norm(x[0]), x[0]))


def alphabet_root(media_type='movie'):
    xbmcplugin.setContent(addon_handle, 'videos')
    for letter in list('ABCDEFGHIJKLMNOPQRSTUVWXYZ') + list('0123456789'):
        _add_dir('[B]%s[/B]' % letter,
                 _url(mode='alphabet_search', prefix=letter, media_type=media_type))
    _end()


def _add_alphabet_title_item(item, media_type='movie'):
    if media_type == 'tvshow':
        _add_tmdb_item(item, 'tvshow')
    else:
        _add_tmdb_item(item, 'movie')


def alphabet_search(prefix, media_type='movie'):
    xbmcplugin.setContent(addon_handle, 'videos')
    prefix = (prefix or '').upper()
    items = _alphabet_get_items(prefix, media_type=media_type)

    if not items:
        return _fail('Pro prefix %s nebyly nalezeny zadne vysledky' % prefix)

    children = _alphabet_probe_children(prefix, media_type=media_type, items=items)
    if not children:
        for item in items:
            _add_alphabet_title_item(item, media_type=media_type)
        return _end()

    if len(items) <= 20:
        for item in items:
            _add_alphabet_title_item(item, media_type=media_type)
        return _end()

    for child, cnt in children:
        _add_dir('[B]%s[/B]  [I](%d)[/I]' % (child, cnt),
                 _url(mode='alphabet_search', prefix=child, media_type=media_type))
    return _end()


# ══════════════════════════════════════════════════════════════════════════════
#  OBLIBENE
# ══════════════════════════════════════════════════════════════════════════════

def favorites_root():
    xbmcplugin.setContent(addon_handle, 'videos')
    favorites = _load_favorites()

    _add_dir('[B]Vse[/B]', _url(mode='favorites_list', media_type='all'), img='DefaultFavourites.png')
    _add_dir('[B]Filmy[/B]', _url(mode='favorites_list', media_type='movie'), img='DefaultMovies.png')
    _add_dir('[B]Serialy[/B]', _url(mode='favorites_list', media_type='tvshow'), img='DefaultTVShows.png')
    if favorites:
        _add_dir('[COLOR red]Vymazat Můj seznam[/COLOR]', _url(mode='favorites_clear'), folder=False, img='DefaultAddonService.png')
    _end()


def show_favorites_list(media_type='all'):
    xbmcplugin.setContent(addon_handle, 'videos')
    favorites = _load_favorites()
    if media_type != 'all':
        favorites = {k: v for k, v in favorites.items() if v.get('media_type') == media_type}

    if not favorites:
        li = xbmcgui.ListItem('Zatim nemate zadne polozky v Mém seznamu')
        li.setArt({'icon': 'DefaultFavourites.png', 'thumb': 'DefaultFavourites.png'})
        xbmcplugin.addDirectoryItem(addon_handle, '', li, False)
        return _end()

    for fav_key, data in sorted(favorites.items(), key=lambda i: i[1].get('time', 0), reverse=True):
        item = {
            'title': data.get('title', ''),
            'year': data.get('year', ''),
            'plot': data.get('plot', ''),
            'poster': data.get('poster', ''),
            'backdrop': data.get('backdrop', ''),
            'tmdb_id': data.get('tmdb_id', ''),
            'orig_title': data.get('orig_title', data.get('title', '')),
            'genres': [g.strip() for g in (data.get('genres', '') or '').split('/') if g.strip()],
        }
        label = data.get('title', fav_key)
        if data.get('year'):
            label += ' (%s)' % data.get('year')
        if media_type == 'all':
            label += '  [I][%s][/I]' % ('Serial' if data.get('media_type') == 'tvshow' else 'Film')

        li = xbmcgui.ListItem(label)
        poster = data.get('poster', '')
        backdrop = data.get('backdrop', '') or poster
        if poster:
            li.setArt({'thumb': poster, 'poster': poster, 'fanart': backdrop, 'icon': poster})
        _set_info(li, {
            'title': data.get('title', ''),
            'plot': data.get('plot', ''),
            'year': int(data.get('year')) if str(data.get('year', '')).isdigit() else 0,
            'genre': data.get('genres', '').replace(' / ', ', '),
            'mediatype': 'movie' if data.get('media_type') == 'movie' else 'tvshow',
        })
        li.addContextMenuItems([
            ('Odebrat z Mého seznamu', 'RunPlugin(%s)' % _url(mode='favorite_remove', media_type=data.get('media_type', 'movie'), tmdb_id=data.get('tmdb_id', ''), title=data.get('title', '')))
        ])

        if data.get('media_type') == 'movie':
            url = _url(mode='select_quality', title=data.get('title', ''), year=data.get('year', ''),
                       orig_title=data.get('orig_title', data.get('title', '')), tmdb_id=data.get('tmdb_id', ''))
        else:
            url = _url(mode='series_list', serial_title=data.get('title', ''), serial_year=data.get('year', ''),
                       serial_original_name=data.get('orig_title', data.get('title', '')), tmdb_id=data.get('tmdb_id', ''))
        xbmcplugin.addDirectoryItem(addon_handle, url, li, True)
    _end()


def favorite_add(media_type='movie', tmdb_id='', title='', year='', orig_title='', plot='', poster='', backdrop='', genres=''):
    favorites = _load_favorites()
    key = _favorite_key(media_type, tmdb_id, title)
    favorites[key] = {
        'media_type': media_type or 'movie',
        'tmdb_id': tmdb_id or '',
        'title': title or '',
        'year': year or '',
        'orig_title': orig_title or title or '',
        'plot': plot or '',
        'poster': poster or '',
        'backdrop': backdrop or '',
        'genres': genres or '',
        'time': int(_time_mod.time()),
    }
    _save_favorites(favorites)
    _notify('Pridano do Mého seznamu')
    xbmc.executebuiltin('Container.Refresh')


def favorite_remove(media_type='movie', tmdb_id='', title=''):
    favorites = _load_favorites()
    key = _favorite_key(media_type, tmdb_id, title)
    if key in favorites:
        del favorites[key]
        _save_favorites(favorites)
    _notify('Odebrano z Mého seznamu')
    xbmc.executebuiltin('Container.Refresh')


def favorites_clear():
    favorites = _load_favorites()
    if not favorites:
        _notify('Můj seznam je prazdny')
        return _fail()
    if xbmcgui.Dialog().yesno('Kino Stream', 'Opravdu chcete vymazat celý Můj seznam?'):
        _save_favorites({})
        _notify('Můj seznam byl vymazan')
        xbmc.executebuiltin('Container.Refresh')
    return _fail()


# ══════════════════════════════════════════════════════════════════════════════
#  NAPOSLEDY SLEDOVANE — identicky s show_watched_items() z provider.py
# ══════════════════════════════════════════════════════════════════════════════

def recent_root():
    xbmcplugin.setContent(addon_handle, 'videos')
    recent = _load_recent_played()
    if not recent:
        _notify('Historie prehravani je prazdna')
        return _fail()

    _add_dir('[B]Vse[/B]', _url(mode='recent_list', media_type='all'),
             img='DefaultRecentlyAddedMovies.png')
    if any(v.get('media_type') == 'movie' for v in recent.values()):
        _add_dir('[B]Filmy[/B]', _url(mode='recent_list', media_type='movie'),
                 img='DefaultMovies.png')
    if any(v.get('media_type') == 'tvshow' for v in recent.values()):
        _add_dir('[B]Serialy[/B]', _url(mode='recent_list', media_type='tvshow'),
                 img='DefaultTVShows.png')
    _add_dir('[COLOR red]Vymazat historii prehravani[/COLOR]',
             _url(mode='recent_clear'), folder=False, img='DefaultAddonService.png')
    _end()


def show_recent_played_list(media_type='all'):
    xbmcplugin.setContent(addon_handle, 'videos')
    recent = _load_recent_played()
    if media_type != 'all':
        recent = {k: v for k, v in recent.items() if v.get('media_type') == media_type}

    if not recent:
        _notify('Zadne naposledy prehrane polozky')
        return _fail()

    for ident, data in sorted(recent.items(), key=lambda i: i[1].get('time', 0), reverse=True):
        type_badge = ''
        if media_type == 'all':
            type_badge = ' [I][%s][/I]' % ('Serial' if data.get('media_type') == 'tvshow' else 'Film')
        label = data.get('title', ident) + type_badge
        if data.get('size'):
            label += '  [I][%s][/I]' % data.get('size', '')

        li = xbmcgui.ListItem(label)
        li.setProperty('IsPlayable', 'true')
        if data.get('img'):
            li.setArt({'thumb': data['img'], 'poster': data['img'], 'icon': data['img']})
        li.addContextMenuItems([
            ('Odebrat z historie prehravani',
             'RunPlugin(%s)' % _url(mode='recent_remove', ident=ident))
        ])
        xbmcplugin.addDirectoryItem(addon_handle,
            _url(mode='play', ident=ident, title=data.get('title', ''),
                 size=data.get('size', ''), img=data.get('img', ''),
                 media_type=data.get('media_type', 'movie')), li, False)
    _end()


def show_watched_list(media_type='movie'):
    xbmcplugin.setContent(addon_handle, 'videos')
    watched = _load_watched()
    items = {k: v for k, v in watched.items()
             if v.get('media_type') == media_type}

    if not items:
        _notify('Zadne sledovane polozky')
        return _fail()

    for ident, data in sorted(items.items(),
                               key=lambda i: i[1]['time'], reverse=True):
        label = data['title'] + '  [I][%s][/I]' % data.get('size', '')
        li = xbmcgui.ListItem(label)
        li.setProperty('IsPlayable', 'true')
        if data.get('img'):
            li.setArt({'thumb': data['img'], 'poster': data['img'], 'icon': data['img']})
        li.addContextMenuItems([
            ('Odebrat ze Sledovanych',
             'RunPlugin(%s)' % _url(mode='remove_watched', ident=ident))
        ])
        xbmcplugin.addDirectoryItem(addon_handle,
            _url(mode='play', ident=ident, title=data['title'],
                 size=data.get('size', ''), img=data.get('img', ''),
                 media_type=data.get('media_type', media_type)), li, False)
    _end()


def watched_add(ident, title, size='', img='', media_type='movie'):
    """Identicky s _add_watched() z provider.py."""
    watched = _load_watched()
    watched[ident] = {
        'title': title, 'size': size, 'img': img,
        'time': int(_time_mod.time()), 'media_type': media_type,
    }
    _save_watched(_trim_watched(watched))
    _notify('Pridano do Sledovanych')


def watched_remove(ident):
    """Identicky s _remove_watched() z provider.py."""
    watched = _load_watched()
    if ident in watched:
        del watched[ident]
        _save_watched(watched)
    _notify('Odebrano. Zmena se projevi po dalsim otevreni.')
    xbmc.executebuiltin('Container.Refresh')


def recent_remove(ident):
    recent = _load_recent_played()
    if ident in recent:
        del recent[ident]
        _save_recent_played(recent)
    _notify('Odebrano z historie prehravani')
    xbmc.executebuiltin('Container.Refresh')


def recent_clear():
    recent = _load_recent_played()
    if not recent:
        _notify('Historie prehravani je prazdna')
        return _fail()
    if xbmcgui.Dialog().yesno('Kino Stream', 'Opravdu chcete vymazat historii prehravani?'):
        _save_recent_played({})
        _notify('Historie prehravani byla vymazana')
        xbmc.executebuiltin('Container.Refresh')
    return _fail()


def _auto_recent_played(ident, title, size='', img='', media_type='movie'):
    recent = _load_recent_played()
    recent[ident] = {
        'title': title, 'size': size, 'img': img,
        'time': int(_time_mod.time()), 'media_type': media_type,
    }
    _save_recent_played(_trim_recent_played(recent))


# ══════════════════════════════════════════════════════════════════════════════
#  PREHRAVANI — identicky s resolve() z provider.py
# ══════════════════════════════════════════════════════════════════════════════

def play_file(ident, title='', size='', img='', media_type='movie', serial_title='', serial_original_name='', season='', episode='', tmdb_id='', poster='', backdrop=''):
    """Resolve stream a ulozi polozku do historie naposledy prehranych."""
    token = _get_token()
    if not token:
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        return

    link = webshare.get_file_link(token, ident)
    if not link:
        # Re-login a zkus znovu
        token = _get_token(force=True)
        if token:
            link = webshare.get_file_link(token, ident)

    if not link:
        _notify('Nelze ziskat odkaz. Zkontrolujte Webshare VIP ucet.',
                xbmcgui.NOTIFICATION_ERROR, 5000)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        return

    li = xbmcgui.ListItem(title, path=link)
    li.setProperty('IsPlayable', 'true')
    # MIME type podle pripony
    ext = (title or '').lower().rsplit('.', 1)[-1]
    mime_map = {'mkv': 'video/x-matroska', 'mp4': 'video/mp4', 'm4v': 'video/mp4',
                'avi': 'video/avi', 'ts': 'video/mp2t', 'm2ts': 'video/mp2t'}
    li.setMimeType(mime_map.get(ext, 'video/x-matroska'))
    li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(addon_handle, True, li)
    _auto_recent_played(ident, title, size=size, img=img, media_type=media_type)
    if (media_type or '') == 'tvshow' and season and episode and serial_title:
        try:
            _send_upnext_payload(_build_upnext_payload(serial_title, serial_original_name, season, episode, tmdb_id=tmdb_id, poster=poster or img, backdrop=backdrop, current_ident=ident, current_title=title))
        except Exception as exc:
            xbmc.log('Kino Stream Up Next play_file failed: %s' % exc, xbmc.LOGWARNING)



def play_file_direct(ident, title='', size='', img='', media_type='movie', serial_title='', serial_original_name='', season='', episode='', tmdb_id='', poster='', backdrop=''):
    """Direct play from custom dialog (select_quality opened as folder, so setResolvedUrl is not reliable)."""
    token = _get_token()
    if not token:
        _notify('Nelze se přihlásit na Webshare.', xbmcgui.NOTIFICATION_ERROR, 4000)
        return False

    link = webshare.get_file_link(token, ident)
    if not link:
        token = _get_token(force=True)
        if token:
            link = webshare.get_file_link(token, ident)

    if not link:
        _notify('Nelze ziskat odkaz. Zkontrolujte Webshare VIP ucet.', xbmcgui.NOTIFICATION_ERROR, 5000)
        return False

    li = xbmcgui.ListItem(title, path=link)
    li.setProperty('IsPlayable', 'true')
    ext = (title or '').lower().rsplit('.', 1)[-1]
    mime_map = {'mkv': 'video/x-matroska', 'mp4': 'video/mp4', 'm4v': 'video/mp4',
                'avi': 'video/avi', 'ts': 'video/mp2t', 'm2ts': 'video/mp2t'}
    li.setMimeType(mime_map.get(ext, 'video/x-matroska'))
    li.setContentLookup(False)
    try:
        xbmc.Player().play(link, li)
        _auto_recent_played(ident, title, size=size, img=img, media_type=media_type)
        if (media_type or '') == 'tvshow' and season and episode and serial_title:
            try:
                _send_upnext_payload(_build_upnext_payload(serial_title, serial_original_name, season, episode, tmdb_id=tmdb_id, poster=poster or img, backdrop=backdrop, current_ident=ident, current_title=title))
            except Exception as exc:
                xbmc.log('Kino Stream Up Next play_file_direct failed: %s' % exc, xbmc.LOGWARNING)
        return True
    except Exception:
        return False





def download_webshare_file(ident, title='', size='', img='', media_type='movie'):
    """Stáhne soubor z Webshare přes integrovaný download helper."""
    token = _get_token()
    if not token:
        _notify('Nelze se přihlásit na Webshare.', xbmcgui.NOTIFICATION_ERROR, 4000)
        return _fail()

    link = webshare.get_file_link(token, ident)
    if not link:
        token = _get_token(force=True)
        if token:
            link = webshare.get_file_link(token, ident)

    if not link:
        _notify('Nelze ziskat odkaz pro stazeni. Zkontrolujte Webshare VIP ucet.', xbmcgui.NOTIFICATION_ERROR, 5000)
        return _fail()

    try:
        mgr = DownloadManager()
        mgr.download(ident or title, link, title or ident or 'download')
        xbmc.executebuiltin('Container.Refresh')
    except DownloadError as exc:
        _notify('Chyba stahovani: %s' % exc, xbmcgui.NOTIFICATION_ERROR, 5000)
    return _fail()



def _resolve_noop():
    """Gracefully finish a plugin callback that intentionally did nothing.

    This is used for actions like canceling a delete dialog, where Kodi should
    not show 'unplayable item' just because the plugin route was invoked.
    """
    try:
        li = xbmcgui.ListItem()
        xbmcplugin.setResolvedUrl(addon_handle, True, li)
    except Exception:
        try:
            xbmcplugin.endOfDirectory(addon_handle, succeeded=True, updateListing=False, cacheToDisc=False)
        except Exception:
            pass
    return True


def delete_local_file(path='', name=''):
    if not path:
        _notify('Chybi cesta k souboru.', xbmcgui.NOTIFICATION_ERROR, 3000)
        return _resolve_noop()

    try:
        path = unquote_plus(path)
    except Exception:
        pass

    try:
        translated = xbmcvfs.translatePath(path)
    except Exception:
        translated = path

    real_path = os.path.normpath(translated or path)
    download_dir = os.path.normpath(_translate_path(addon.getSetting('download_path') or '') or '')
    if not download_dir:
        try:
            download_dir = os.path.normpath(_translate_path('special://profile/addon_data/%s/downloads/' % addon.getAddonInfo('id')))
        except Exception:
            download_dir = real_path

    try:
        safe_root = os.path.normcase(download_dir)
        safe_path = os.path.normcase(real_path)
        if safe_root and os.path.commonpath([safe_root, safe_path]) != safe_root:
            _notify('Mazani mimo slozku stahovani neni povoleno.', xbmcgui.NOTIFICATION_ERROR, 4000)
            return _fail()
    except Exception:
        pass

    label = name or os.path.basename(real_path) or 'soubor'
    if not xbmcgui.Dialog().yesno(
        addon.getAddonInfo('name'),
        'Opravdu smazat?\nSoubor: %s' % label,
        nolabel='Ne',
        yeslabel='Ano'
    ):
        return _resolve_noop()

    existed = False
    try:
        existed = xbmcvfs.exists(real_path)
    except Exception:
        existed = False
    if not existed:
        try:
            existed = os.path.exists(real_path)
        except Exception:
            existed = False

    ok = False
    try:
        ok = xbmcvfs.delete(real_path)
    except Exception:
        ok = False
    if not ok:
        try:
            if os.path.exists(real_path):
                os.remove(real_path)
                ok = True
            else:
                ok = existed is False
        except Exception:
            ok = False

    if ok:
        try:
            download_store.remove_by_target_path(real_path)
        except Exception:
            pass
        _notify('Soubor smazan.', xbmcgui.NOTIFICATION_INFO, 2500)
        xbmc.executebuiltin('Container.Refresh')
    else:
        _notify('Soubor se nepodarilo smazat.', xbmcgui.NOTIFICATION_ERROR, 4000)
    return _fail()


def downloaded_item_action(path='', name=''):
    picked = show_downloaded_item_actions(path, name)
    if picked == 'play':
        return play_local_file(path)
    if picked == 'delete':
        return delete_local_file(path, name)
    return _resolve_noop()


def play_local_file(path=''):
    """Přehraje lokální soubor korektně přes setResolvedUrl.

    Předchozí varianta zkoušela míchat xbmc.Player().play(), PlayMedia() a
    následně vracela failed stav pluginu. To v Kodi vedlo ke hlášce
    "skipping unplayable item" i když soubor fyzicky existoval.
    """
    if not path:
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        return False

    try:
        path = unquote_plus(path)
    except Exception:
        pass

    try:
        translated = xbmcvfs.translatePath(path)
    except Exception:
        translated = path

    real_path = translated or path
    if not real_path:
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        return False

    try:
        normalized = os.path.normpath(real_path)
    except Exception:
        normalized = real_path

    exists = False
    try:
        exists = xbmcvfs.exists(normalized)
    except Exception:
        exists = False
    if not exists:
        try:
            exists = os.path.exists(normalized)
        except Exception:
            exists = False

    if not exists:
        _notify('Soubor nebyl nalezen: %s' % normalized, xbmcgui.NOTIFICATION_ERROR, 4000)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        return False

    li = xbmcgui.ListItem(path=normalized)
    li.setProperty('IsPlayable', 'true')
    li.setLabel(os.path.basename(normalized))
    ext = (normalized or '').lower().rsplit('.', 1)[-1] if '.' in (normalized or '') else ''
    mime_map = {
        'mkv': 'video/x-matroska', 'mp4': 'video/mp4', 'm4v': 'video/mp4',
        'avi': 'video/x-msvideo', 'ts': 'video/mp2t', 'm2ts': 'video/mp2t',
        'mov': 'video/quicktime', 'wmv': 'video/x-ms-wmv'
    }
    mime = mime_map.get(ext)
    if mime:
        try:
            li.setMimeType(mime)
        except Exception:
            pass
    try:
        li.setContentLookup(False)
    except Exception:
        pass

    xbmcplugin.setResolvedUrl(addon_handle, True, li)
    return True


# ══════════════════════════════════════════════════════════════════════════════
#  ROUTER
# ══════════════════════════════════════════════════════════════════════════════

def router(params):
    mode = params.get('mode') or params.get('action')

    if   mode is None:               main_menu()
    elif mode == 'media_root':       media_root(params.get('media_type', 'movie'))
    elif mode == 'search':           do_search(params.get('search_id', ''))
    elif mode == 'search_more':      search_more(params.get('keyword', ''),
                                                 params.get('search_id', 'movie'),
                                                 int(params.get('page', 1)))
    elif mode == 'search_run':       execute_search(params.get('keyword', ''),
                                                    params.get('search_id', 'movie'),
                                                    int(params.get('page', 1)))
    elif mode == 'genre_list':       show_genre_list(params.get('media_type', 'movie'))
    elif mode == 'genre_movies':     show_genre_movies(
                                         params.get('genre_id', ''),
                                         params.get('genre_name', ''),
                                         params.get('media_type', 'movie'),
                                         int(params.get('page', 1)))
    elif mode == 'country_list':     show_country_list(params.get('media_type', 'movie'))
    elif mode == 'country_movies':   show_country_movies(
                                         params.get('country_code', ''),
                                         params.get('country_name', ''),
                                         params.get('media_type', 'movie'),
                                         int(params.get('page', 1)))
    elif mode == 'trending_movies':  show_trending_movies()
    elif mode == 'popular_movies':   show_popular_movies(int(params.get('page', 1)))
    elif mode == 'select_quality':   select_quality(
                                         params.get('title', ''),
                                         params.get('year', ''),
                                         params.get('orig_title', ''),
                                         params.get('tmdb_id', ''))
    elif mode == 'quality_select':   show_quality_select(
                                         params.get('variants', '[]'),
                                         params.get('media_type', 'movie'),
                                         params.get('poster', ''),
                                         params.get('backdrop', ''))
    elif mode == 'series_list':      show_series_list(
                                         params.get('serial_title', ''),
                                         params.get('serial_year', ''),
                                         params.get('serial_original_name', ''),
                                         params.get('tmdb_id', ''),
                                         params.get('num_seasons', 0))
    elif mode == 'episodes':         show_episodes(
                                         params.get('serial_title', ''),
                                         params.get('season', 1),
                                         params.get('serial_year', ''),
                                         params.get('serial_original_name', ''),
                                         params.get('tmdb_id', ''))
    elif mode == 'episode_variants': show_episode_variants(
                                         params.get('variants', '[]'),
                                         params.get('season', 1),
                                         params.get('ep_num', 1),
                                         params.get('ep_name', ''),
                                         params.get('ep_plot', ''),
                                         params.get('serial_title', ''),
                                         params.get('serial_original_name', ''),
                                         params.get('tmdb_id', ''),
                                         params.get('poster', ''),
                                         params.get('backdrop', ''))
    elif mode == 'alphabet_root':    alphabet_root(params.get('media_type', 'movie'))
    elif mode == 'alphabet_search':  alphabet_search(params.get('prefix', 'A'),
                                                     params.get('media_type', 'movie'))
    elif mode == 'favorites_root':   favorites_root()
    elif mode == 'favorites_list':   show_favorites_list(params.get('media_type', 'all'))
    elif mode == 'favorite_add':     favorite_add(
                                         media_type=params.get('media_type', 'movie'),
                                         tmdb_id=params.get('tmdb_id', ''),
                                         title=params.get('title', ''),
                                         year=params.get('year', ''),
                                         orig_title=params.get('orig_title', ''),
                                         plot=params.get('plot', ''),
                                         poster=params.get('poster', ''),
                                         backdrop=params.get('backdrop', ''),
                                         genres=params.get('genres', ''))
    elif mode == 'favorite_remove':  favorite_remove(
                                         media_type=params.get('media_type', 'movie'),
                                         tmdb_id=params.get('tmdb_id', ''),
                                         title=params.get('title', ''))
    elif mode == 'favorites_clear':  favorites_clear()
    elif mode == 'recent_root':      recent_root()
    elif mode == 'recent_list':      show_recent_played_list(params.get('media_type', 'all'))
    elif mode == 'recent_remove':    recent_remove(params.get('ident', ''))
    elif mode == 'recent_clear':     recent_clear()
    elif mode == 'watched_list':     show_watched_list(params.get('media_type', 'movie'))
    elif mode == 'add_watched':      watched_add(
                                         params.get('ident', ''),
                                         params.get('title', ''),
                                         params.get('size', ''),
                                         params.get('img', ''),
                                         media_type=params.get('media_type', 'movie'))
    elif mode == 'remove_watched':   watched_remove(params.get('ident', ''))
    elif mode == 'play':             play_file(params.get('ident', ''),
                                               params.get('title', ''),
                                               params.get('size', ''),
                                               params.get('img', ''),
                                               params.get('media_type', 'movie'),
                                               params.get('serial_title', ''),
                                               params.get('serial_original_name', ''),
                                               params.get('season', ''),
                                               params.get('episode', ''),
                                               params.get('tmdb_id', ''),
                                               params.get('poster', ''),
                                               params.get('backdrop', ''))
    elif mode == 'download_ws':      download_webshare_file(params.get('ident', ''),
                                               params.get('title', ''),
                                               params.get('size', ''),
                                               params.get('img', ''),
                                               params.get('media_type', 'movie'))
    elif mode == 'downloads':        list_downloaded_files()
    elif mode == 'download_item_action': downloaded_item_action(params.get('path', ''), params.get('name', ''))
    elif mode == 'delete_local':     delete_local_file(params.get('path', ''), params.get('name', ''))
    elif mode == 'play_local':       play_local_file(params.get('path', ''))
    elif mode == 'account_info':     show_account_info()
    elif mode == 'do_login':         do_login()
    elif mode == 'send_feedback':    send_feedback()
    elif mode == 'settings':         addon.openSettings(); _fail()
    else:                            main_menu()
